import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import supertest from "supertest";
import JSZip from "jszip";
import { createApp } from "../server/app.mjs";
import { Store, sha256, stable } from "../server/store.mjs";
import { passwordHash } from "../server/security.mjs";
const PASSWORD = "a private passphrase 2026";
async function fixture(t, options = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "vaultshare-api-"));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const app = await createApp({
    dataDir: path.join(root, "data"),
    maxUploadMB: 1,
    quotaMB: 2,
    ...options,
  });
  return { root, app, store: app.locals.store };
}
async function register(app, username) {
  const client = supertest.agent(app);
  let response = await client.get("/api/session");
  response = await client
    .post("/api/register")
    .set("X-CSRF-Token", response.body.csrf)
    .send({
      username,
      display_name: username.toUpperCase(),
      password: PASSWORD,
    });
  assert.equal(response.status, 201, JSON.stringify(response.body));
  return { client, uid: response.body.user.id, csrf: response.body.csrf };
}
async function trio(app) {
  return Promise.all(
    ["alice", "bob", "carol"].map((name) => register(app, name)),
  );
}
function upload(
  user,
  receiver,
  files = [Buffer.from("Hello from the LAN!")],
  paths = ["hello.txt"],
  hours = 24,
) {
  let request = user.client
    .post("/api/transfers")
    .set("X-CSRF-Token", user.csrf)
    .field("recipient_id", receiver)
    .field("expiry_hours", String(hours))
    .field("paths", JSON.stringify(paths));
  files.forEach((buffer, i) => {
    request = request.attach("files", buffer, {
      filename: paths[i].split("/").at(-1),
    });
  });
  return request;
}
const action = (user, tid, name) =>
  user.client
    .post(`/api/transfers/${tid}/${name}`)
    .set("X-CSRF-Token", user.csrf)
    .send({});

test("approval, recipient-only download, hash verification and private logs", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob, carol] = await trio(app);
  const response = await upload(alice, bob.uid);
  assert.equal(response.status, 201);
  const transfer = response.body.transfer,
    tid = transfer.id,
    route = `/api/transfers/${tid}/download`;
  assert.equal((await bob.client.get(route)).status, 403);
  assert.equal((await alice.client.get(route)).status, 404);
  assert.equal((await carol.client.get(route)).status, 404);
  assert.equal((await action(alice, tid, "accept")).status, 403);
  assert.equal((await action(carol, tid, "accept")).status, 404);
  assert.equal((await action(bob, tid, "revoke")).status, 403);
  assert.equal((await action(bob, tid, "accept")).status, 200);
  assert.equal((await action(bob, tid, "accept")).status, 409);
  const downloaded = await bob.client.get(route);
  assert.equal(downloaded.body.toString(), "Hello from the LAN!");
  assert.equal(
    downloaded.headers["x-vaultshare-sha256"],
    sha256(downloaded.body),
  );
  assert.equal(downloaded.headers["x-vaultshare-integrity"], "verified");
  assert.match(downloaded.headers["content-disposition"], /attachment/);
  assert.deepEqual(
    (await carol.client.get("/api/dashboard")).body.transfers,
    [],
  );
  assert(
    !(await carol.client.get("/api/dashboard")).body.logs.some(
      (log) => log.transfer_id === tid,
    ),
  );
  assert(
    (await alice.client.get("/api/dashboard")).body.logs.some(
      (log) => log.action === "download_verified",
    ),
  );
  assert(
    !fs
      .readFileSync(path.join(store.blobs, tid + ".vault"))
      .includes(Buffer.from("Hello from the LAN!")),
  );
});
test("folder archive preserves paths and per-file digests", async (t) => {
  const { app } = await fixture(t);
  const [alice, bob] = await trio(app);
  const contents = [
      Buffer.from("<h1>Project</h1>"),
      Buffer.from("print(42)"),
      Buffer.alloc(0),
    ],
    paths = ["project/index.html", "project/src/main.py", "project/empty.txt"];
  const response = await upload(alice, bob.uid, contents, paths);
  assert.equal(response.status, 201);
  const transfer = response.body.transfer;
  assert.equal(transfer.kind, "folder");
  assert.equal(transfer.name, "project.zip");
  assert.equal(transfer.file_count, 3);
  await action(bob, transfer.id, "accept");
  const result = await bob.client.get(`/api/transfers/${transfer.id}/download`);
  const zip = await JSZip.loadAsync(result.body);
  for (let i = 0; i < paths.length; i++) {
    assert.deepEqual(await zip.file(paths[i]).async("nodebuffer"), contents[i]);
    assert.equal(transfer.entries[i].sha256, sha256(contents[i]));
  }
  assert.equal(transfer.sha256, sha256(result.body));
});
for (const value of [
  "../private.txt",
  "/root/file",
  "folder/../file",
  "folder\\file",
  "folder//file",
  "folder/./file",
  "NUL.txt",
  "file:ads",
  "name.",
  "file\0name",
])
  test(`unsafe path blocked: ${JSON.stringify(value)}`, async (t) => {
    const { app } = await fixture(t);
    const [alice, bob] = await trio(app);
    assert.equal(
      (await upload(alice, bob.uid, [Buffer.from("x")], [value])).status,
      400,
    );
  });
for (const paths of [
  ["a.txt", "A.txt"],
  ["folder", "folder/file"],
  ["Folder", "folder/file"],
])
  test(`path collision blocked: ${paths.join(",")}`, async (t) => {
    const { app } = await fixture(t);
    const [alice, bob] = await trio(app);
    assert.equal(
      (
        await upload(
          alice,
          bob.uid,
          [Buffer.from("a"), Buffer.from("b")],
          paths,
        )
      ).status,
      400,
    );
  });
for (const name of ["decline", "revoke"])
  test(`${name} removes encrypted payload and blocks later approval`, async (t) => {
    const { app, store } = await fixture(t);
    const [alice, bob] = await trio(app);
    const tid = (await upload(alice, bob.uid)).body.transfer.id;
    assert.equal(
      (await action(name === "revoke" ? alice : bob, tid, name)).status,
      200,
    );
    assert(!fs.existsSync(path.join(store.blobs, tid + ".vault")));
    assert.equal(
      (await bob.client.get(`/api/transfers/${tid}/download`)).status,
      403,
    );
    assert.equal((await action(bob, tid, "accept")).status, 409);
  });
test("accepted transfer can be revoked by sender", async (t) => {
  const { app } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  await action(bob, tid, "accept");
  assert.equal((await action(alice, tid, "revoke")).status, 200);
  assert.equal(
    (await bob.client.get(`/api/transfers/${tid}/download`)).status,
    403,
  );
});
test("expiry blocks approval and download before cleanup", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  store.transaction(() => {
    store.state.transfers[tid].expires_at = Date.now() / 1000 - 1;
  });
  assert.equal((await action(bob, tid, "accept")).status, 409);
  assert.equal(
    (await bob.client.get(`/api/transfers/${tid}/download`)).status,
    403,
  );
  assert.equal(store.state.transfers[tid].status, "expired");
  assert(!fs.existsSync(path.join(store.blobs, tid + ".vault")));
});
test("tampered ciphertext is blocked and logged", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  await action(bob, tid, "accept");
  const file = path.join(store.blobs, tid + ".vault"),
    bytes = fs.readFileSync(file);
  bytes[bytes.length - 1] ^= 1;
  fs.writeFileSync(file, bytes);
  const result = await bob.client.get(`/api/transfers/${tid}/download`);
  assert.equal(result.status, 409);
  assert.equal(store.state.transfers[tid].status, "corrupt");
  assert(store.state.logs.some((log) => log.action === "integrity_failed"));
});
test("immutable metadata is authenticated with payload", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  await action(bob, tid, "accept");
  store.transaction(() => {
    store.state.transfers[tid].name = "changed.txt";
  });
  assert.equal(
    (await bob.client.get(`/api/transfers/${tid}/download`)).status,
    409,
  );
});
test("tampered metadata and missing encryption keys fail closed", async (t) => {
  const { app, store } = await fixture(t);
  await register(app, "alice");
  const original = fs.readFileSync(store.statePath, "utf8"),
    envelope = JSON.parse(original);
  envelope.payload = JSON.stringify({
    ...JSON.parse(envelope.payload),
    users: {},
  });
  fs.writeFileSync(store.statePath, JSON.stringify(envelope));
  assert.throws(() => new Store(store.root), /integrity/);
  fs.writeFileSync(store.statePath, original);
  fs.unlinkSync(path.join(store.root, "keys.bin"));
  assert.throws(() => new Store(store.root), /key missing/);
});
test("missing metadata preserves remaining ciphertext", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  fs.unlinkSync(store.statePath);
  assert.throws(() => new Store(store.root), /Metadata missing/);
  assert(fs.existsSync(path.join(store.blobs, tid + ".vault")));
});
test("restart preserves accounts and accepted payloads", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const tid = (await upload(alice, bob.uid)).body.transfer.id;
  await action(bob, tid, "accept");
  const restarted = await createApp({ dataDir: store.root });
  const client = supertest.agent(restarted);
  const csrf = (await client.get("/api/session")).body.csrf;
  assert.equal(
    (
      await client
        .post("/api/login")
        .set("X-CSRF-Token", csrf)
        .send({ username: "bob", password: PASSWORD })
    ).status,
    200,
  );
  assert.equal(
    (await client.get(`/api/transfers/${tid}/download`)).body.toString(),
    "Hello from the LAN!",
  );
  assert(!fs.readdirSync(store.root).some((name) => name.endsWith(".db")));
});
test("CSRF, origin, password hashes and session rotation", async (t) => {
  const { app, store } = await fixture(t);
  const client = supertest.agent(app);
  assert.equal((await client.post("/api/register").send({})).status, 403);
  const csrf = (await client.get("/api/session")).body.csrf;
  assert.equal(
    (
      await client
        .post("/api/register")
        .set("X-CSRF-Token", csrf)
        .set("Origin", "http://evil.example")
        .send({})
    ).status,
    403,
  );
  const alice = await register(app, "alice");
  assert(!fs.readFileSync(store.statePath, "utf8").includes(PASSWORD));
  assert.match(store.state.users[alice.uid].password_hash, /^scrypt:/);
  assert.equal((await client.get("/api/dashboard")).status, 401);
  assert.equal(
    (
      await client
        .post("/api/login")
        .set("X-CSRF-Token", csrf)
        .send({ username: "alice", password: "wrong" })
    ).status,
    401,
  );
  const login = await client
    .post("/api/login")
    .set("X-CSRF-Token", csrf)
    .send({ username: "alice", password: PASSWORD });
  assert.equal(login.status, 200);
  assert.equal(
    (await client.post("/api/logout").set("X-CSRF-Token", csrf).send({}))
      .status,
    403,
  );
  assert.equal(
    (
      await client
        .post("/api/logout")
        .set("X-CSRF-Token", login.body.csrf)
        .send({})
    ).status,
    200,
  );
  assert.equal((await client.get("/api/dashboard")).status, 401);
});
test("HTTP cookies, CSP and credential-free health check", async (t) => {
  const { app } = await fixture(t);
  const result = await supertest(app).get("/api/session");
  const cookie = result.headers["set-cookie"][0];
  assert.match(cookie, /HttpOnly/);
  assert.match(cookie, /SameSite=Strict/);
  assert(!cookie.includes("; Secure"));
  assert.match(result.headers["content-security-policy"], /frame-ancestors/);
  const health = await supertest(app).get("/healthz");
  assert.deepEqual(health.body, {
    service: "Vault Share",
    status: "ready",
    edition: "React",
  });
  assert(!health.headers["set-cookie"]);
});
test("presence, explicit logout and stale browser sessions", async (t) => {
  const { app } = await fixture(t);
  const [alice, bob, carol] = await trio(app);
  assert.equal((await alice.client.get("/api/dashboard")).body.users.length, 2);
  await bob.client.post("/api/logout").set("X-CSRF-Token", bob.csrf).send({});
  assert.deepEqual(
    (await alice.client.get("/api/dashboard")).body.users.map((u) => u.id),
    [carol.uid],
  );
  for (const session of app.locals.sessions.values())
    if (session.uid === carol.uid) session.seen -= 40;
  assert.equal((await alice.client.get("/api/dashboard")).body.users.length, 0);
});
test("self-send, expiry validation, aggregate size limit and zero-byte files", async (t) => {
  const { app } = await fixture(t);
  const [alice, bob] = await trio(app);
  assert.equal((await upload(alice, alice.uid)).status, 400);
  assert.equal(
    (await upload(alice, bob.uid, undefined, undefined, -1)).status,
    400,
  );
  assert.equal(
    (await upload(alice, bob.uid, [Buffer.alloc(1024 * 1024 + 1)])).status,
    413,
  );
  assert.equal(
    (
      await upload(
        alice,
        bob.uid,
        [Buffer.alloc(600 * 1024), Buffer.alloc(600 * 1024)],
        ["a", "b"],
      )
    ).status,
    413,
  );
  assert.equal((await upload(alice, bob.uid, [Buffer.alloc(0)])).status, 201);
});
test("storage quota and simultaneous requests preserve atomic metadata", async (t) => {
  const { app, store } = await fixture(t);
  const [alice, bob] = await trio(app);
  const results = await Promise.all([
    upload(alice, bob.uid, [Buffer.alloc(1024 * 1024)], ["a"]),
    upload(alice, bob.uid, [Buffer.alloc(1024 * 1024)], ["b"]),
  ]);
  assert(results.every((r) => r.status === 201));
  assert.equal((await upload(alice, bob.uid, [Buffer.from("c")])).status, 507);
  const restored = new Store(store.root);
  assert.equal(Object.keys(restored.state.transfers).length, 2);
});
test("sign-in rate limits unknown usernames", async (t) => {
  const { app } = await fixture(t);
  const client = supertest.agent(app),
    csrf = (await client.get("/api/session")).body.csrf;
  for (let i = 0; i < 15; i++)
    assert.equal(
      (
        await client
          .post("/api/login")
          .set("X-CSRF-Token", csrf)
          .send({ username: "nobody", password: PASSWORD })
      ).status,
      401,
    );
  assert.equal(
    (
      await client
        .post("/api/login")
        .set("X-CSRF-Token", csrf)
        .send({ username: "nobody", password: PASSWORD })
    ).status,
    429,
  );
});

test("one-time Python migration preserves password, floating-point AAD and ciphertext", async (t) => {
  const python = spawnSync("python3", ["--version"]);
  if (python.error || python.status) {
    t.skip("Python 3 is required only for the optional legacy migration test.");
    return;
  }
  const { root } = await fixture(t);
  const source = path.join(root, "python"),
    target = path.join(root, "react");
  fs.mkdirSync(path.join(source, "blobs"), { recursive: true });
  const keys = crypto.randomBytes(64),
    sender = "a".repeat(32),
    receiver = "b".repeat(32),
    tid = "c".repeat(32),
    payload = Buffer.from("Migrated legacy file");
  const record = {
    id: tid,
    sender_id: sender,
    recipient_id: receiver,
    name: "legacy.txt",
    kind: "file",
    size: payload.length,
    file_count: 1,
    entries: [
      { path: "legacy.txt", size: payload.length, sha256: sha256(payload) },
    ],
    sha256: sha256(payload),
    created_at: 1700000000,
    expires_at: 4000000000,
    status: "accepted",
    note: "Imported",
    downloads: 0,
    accepted_at: 1700000001,
  };
  const floating = (json) =>
    json
      .replace(/"created_at":1700000000/g, '"created_at":1700000000.0')
      .replace(/"expires_at":4000000000/g, '"expires_at":4000000000.0');
  const fields = Object.fromEntries(
    [
      "id",
      "sender_id",
      "recipient_id",
      "name",
      "kind",
      "size",
      "sha256",
      "created_at",
      "expires_at",
      "file_count",
      "entries",
    ].map((k) => [k, record[k]]),
  );
  const aad = Buffer.from(floating(JSON.stringify(stable(fields))));
  const nonce = crypto.randomBytes(12),
    cipher = crypto.createCipheriv("aes-256-gcm", keys.subarray(0, 32), nonce);
  cipher.setAAD(aad);
  const encrypted = Buffer.concat([
    Buffer.from("VS01"),
    nonce,
    cipher.update(payload),
    cipher.final(),
    cipher.getAuthTag(),
  ]);
  fs.writeFileSync(path.join(source, "blobs", tid + ".vault"), encrypted);
  fs.writeFileSync(path.join(source, "keys.bin"), keys);
  const state = {
    version: 1,
    users: {
      [sender]: {
        username: "alice",
        display_name: "Alice",
        password_hash: await passwordHash(PASSWORD),
      },
      [receiver]: {
        username: "bob",
        display_name: "Bob",
        password_hash: await passwordHash(PASSWORD),
      },
    },
    transfers: { [tid]: record },
    logs: [],
  };
  const raw = floating(JSON.stringify(state));
  fs.writeFileSync(
    path.join(source, "state.json"),
    JSON.stringify({
      payload: raw,
      mac: crypto
        .createHmac("sha256", keys.subarray(32))
        .update(raw)
        .digest("hex"),
    }),
  );
  const result = spawnSync(
    "python3",
    ["scripts/migrate-python.py", "--source", source, "--target", target],
    { encoding: "utf8" },
  );
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.deepEqual(
    fs.readFileSync(path.join(source, "blobs", tid + ".vault")),
    encrypted,
  );
  const imported = await createApp({ dataDir: target }),
    client = supertest.agent(imported),
    csrf = (await client.get("/api/session")).body.csrf;
  assert.equal(
    (
      await client
        .post("/api/login")
        .set("X-CSRF-Token", csrf)
        .send({ username: "bob", password: PASSWORD })
    ).status,
    200,
  );
  assert.deepEqual(
    (await client.get(`/api/transfers/${tid}/download`)).body,
    payload,
  );
  assert.equal(
    spawnSync("python3", [
      "scripts/migrate-python.py",
      "--source",
      source,
      "--target",
      target,
    ]).status,
    1,
  );
});

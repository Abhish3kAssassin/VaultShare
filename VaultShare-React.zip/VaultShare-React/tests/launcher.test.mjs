import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { startHost } from "../server/index.mjs";
import { lanInterfaces, checkHost } from "../server/network.mjs";

const listen = (server) =>
  new Promise((resolve) =>
    server.listen(0, "0.0.0.0", () => resolve(server.address().port)),
  );
const stop = (server) => new Promise((resolve) => server.close(resolve));
async function freePort() {
  const server = http.createServer();
  const port = await listen(server);
  await stop(server);
  return port;
}
function dataDir(t) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "vaultshare-launch-"));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  return dir;
}
test("LAN addresses include Windows Ethernet and prefer physical over VPN interfaces", () => {
  const entry = (address) => ({ address, family: "IPv4", internal: false });
  assert.deepEqual(
    lanInterfaces({
      utun2: [entry("10.0.0.1")],
      "Local Area Connection": [entry("192.168.1.5")],
      en0: [entry("192.168.1.6"), entry("192.168.1.6")],
      lo: [{ ...entry("127.0.0.1"), internal: true }],
      v6: [{ address: "::1", family: "IPv6", internal: false }],
    }),
    [
      { name: "en0", address: "192.168.1.6", virtual: false },
      { name: "Local Area Connection", address: "192.168.1.5", virtual: false },
      { name: "utun2", address: "10.0.0.1", virtual: true },
    ],
  );
});
test("HTTP launcher serves UI and API together, binds LAN, checks readiness and releases its data lock", async (t) => {
  const port = await freePort(),
    dir = dataDir(t),
    output = [],
    original = console.log;
  let host;
  console.log = (...args) => output.push(args.join(" "));
  try {
    host = await startHost([
      "--port",
      String(port),
      "--data-dir",
      dir,
      "--no-browser",
    ]);
  } finally {
    console.log = original;
  }
  t.after(() => host.close());
  assert.equal(host.server.address().address, "0.0.0.0");
  assert.equal((await checkHost(host.localURL)).status, "ready");
  const page = await fetch(host.localURL);
  assert.equal(page.status, 200);
  assert.match(await page.text(), /<div id="root"><\/div>/);
  assert(output.some((line) => line.includes("local HTTP check passed")));
  assert(output.some((line) => line.includes(`http://127.0.0.1:${port}`)));
  await assert.rejects(
    startHost([
      "--port",
      String(await freePort()),
      "--data-dir",
      dir,
      "--no-browser",
    ]),
    /Another host/,
  );
  await host.close();
  assert(!fs.existsSync(dir + ".lock"));
});
test("occupied port fails clearly without reporting ready and releases the data lock", async (t) => {
  const server = http.createServer();
  const port = await listen(server),
    dir = dataDir(t);
  t.after(() => stop(server));
  await assert.rejects(
    startHost(["--port", String(port), "--data-dir", dir, "--no-browser"]),
    /occupied/,
  );
  assert(!fs.existsSync(dir + ".lock"));
});
test("connection check rejects wrong services and HTTPS", async (t) => {
  const server = http.createServer((_req, res) =>
    res.end('{"service":"Another app"}'),
  );
  const port = await listen(server);
  t.after(() => stop(server));
  await assert.rejects(checkHost(`http://127.0.0.1:${port}`), /does not serve/);
  await assert.rejects(checkHost("https://127.0.0.1:8080"), /HTTP/);
});
test("invalid launch settings fail before creating data", async () => {
  await assert.rejects(startHost(["--port", "0"]), /Port/);
  await assert.rejects(startHost(["--host", "https://localhost"]), /Host/);
  await assert.rejects(startHost(["--max-upload-mb", "257"]), /Upload limit/);
});

import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { chromium } from "playwright";
import JSZip from "jszip";
import { createApp } from "../server/app.mjs";
import http from "node:http";

const temp = fs.mkdtempSync(path.join(os.tmpdir(), "vaultshare-browser-")),
  previews = path.resolve("previews");
fs.mkdirSync(previews, { recursive: true });
const app = await createApp({
  dataDir: path.join(temp, "data"),
  distDir: path.resolve("dist"),
});
const server = http.createServer(app);
await new Promise((resolve) => server.listen(0, "0.0.0.0", resolve));
const base = `http://127.0.0.1:${server.address().port}`;
let browser,
  expectedAuthExpiry = false;
const errors = [];
async function until(check, label) {
  const deadline = Date.now() + 18000;
  while (Date.now() < deadline) {
    if (await check()) return;
    await new Promise((resolve) => setTimeout(resolve, 200));
  }
  throw new Error(`Timed out: ${label}`);
}
const card = (page, name) =>
  page
    .locator(".transfer-card")
    .filter({ has: page.locator(".file-title", { hasText: name }) });
async function register(page, display, username) {
  await page.goto(base);
  await page
    .getByRole("button", { name: "Create account", exact: true })
    .click();
  await page.locator("#display-name").fill(display);
  await page.locator("#username").fill(username);
  await page.locator("#password").fill("a private passphrase 2026");
  await page.locator("#auth-form button[type=submit]").click();
  await page.locator("#app-screen").waitFor();
}
async function noOverflow(page) {
  assert(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth + 1,
    ),
    "Horizontal overflow",
  );
}
async function send(page, receiver, { folder, file, note = "" }) {
  await page.locator("#new-transfer").click();
  await page.locator("#recipient").selectOption({ label: receiver });
  if (folder) await page.locator("#folder-input").setInputFiles(folder);
  else await page.locator("#files-input").setInputFiles(file);
  await page.locator("#transfer-note").fill(note);
  await page.locator("#send-submit").click();
  await page.locator("#send-dialog").waitFor({ state: "detached" });
}
try {
  browser = await chromium.launch({
    executablePath: process.env.VS_BROWSER_PATH || undefined,
    headless: true,
    args: ["--no-sandbox", "--disable-dev-shm-usage"],
  });
  const aliceContext = await browser.newContext({
      viewport: { width: 1440, height: 1080 },
      acceptDownloads: true,
    }),
    bobContext = await browser.newContext({
      viewport: { width: 1440, height: 1080 },
      acceptDownloads: true,
    });
  const alice = await aliceContext.newPage(),
    bob = await bobContext.newPage();
  for (const page of [alice, bob]) {
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (message) => {
      if (
        message.type() === "error" &&
        !(expectedAuthExpiry && message.text().includes("401"))
      )
        errors.push(message.text());
    });
  }
  await alice.goto(base);
  await alice.locator("#auth-screen").waitFor();
  await alice.screenshot({
    path: path.join(previews, "VaultShare-React-login.png"),
    fullPage: true,
  });
  await noOverflow(alice);
  await register(alice, "Abhishek Rahang", "abhishek");
  await register(bob, "Riya Sen", "riya");
  await until(
    () =>
      alice
        .locator("#people-list")
        .innerText()
        .then((text) => text.includes("Riya Sen")),
    "online presence",
  );
  const folder = path.join(temp, "Brand assets");
  fs.mkdirSync(path.join(folder, "colors"), { recursive: true });
  fs.writeFileSync(
    path.join(folder, "logo.svg"),
    '<svg xmlns="http://www.w3.org/2000/svg"><rect width="32" height="32" fill="#286cf0"/></svg>',
  );
  fs.writeFileSync(
    path.join(folder, "colors", "palette.txt"),
    "Vault blue #286cf0\nMidnight #142039",
  );
  await send(alice, "Riya Sen (@riya)", {
    folder,
    note: "Everything for our next big thing.",
  });
  await until(() => card(bob, "Brand assets.zip").count(), "incoming folder");
  assert.equal(
    await card(bob, "Brand assets.zip")
      .getByRole("button", { name: "Download", exact: true })
      .count(),
    0,
  );
  await card(bob, "Brand assets.zip")
    .getByRole("button", { name: "Accept", exact: true })
    .click();
  await card(bob, "Brand assets.zip")
    .getByRole("button", { name: "Download", exact: true })
    .waitFor();
  const downloadEvent = bob.waitForEvent("download");
  await card(bob, "Brand assets.zip")
    .getByRole("button", { name: "Download", exact: true })
    .click();
  const download = await downloadEvent;
  const downloaded = fs.readFileSync(await download.path()),
    zip = await JSZip.loadAsync(downloaded);
  assert.equal(
    await zip.file("Brand assets/colors/palette.txt").async("string"),
    "Vault blue #286cf0\nMidnight #142039",
  );
  assert.equal(download.suggestedFilename(), "Brand assets.zip");
  const record = Object.values(app.locals.store.state.transfers).find(
    (t) => t.name === "Brand assets.zip",
  );
  assert.equal(
    crypto.createHash("sha256").update(downloaded).digest("hex"),
    record.sha256,
  );
  await until(
    () =>
      bob
        .locator(".toast")
        .allTextContents()
        .then((text) => text.join(" ").includes("SHA-256 verified")),
    "browser digest verification",
  );
  const notes = path.join(temp, "Project notes.md");
  fs.writeFileSync(notes, "# A little closer\nPlans for the next release.");
  await send(bob, "Abhishek Rahang (@abhishek)", {
    file: notes,
    note: '<img src=x onerror="window.hacked=true">',
  });
  const mockup = path.join(temp, "Interface mockup.svg");
  fs.writeFileSync(
    mockup,
    '<svg xmlns="http://www.w3.org/2000/svg"><text x="10" y="20">Vault Share</text></svg>',
  );
  await send(alice, "Riya Sen (@riya)", { file: mockup });
  await until(
    () => card(alice, "Project notes.md").count(),
    "reverse-direction transfer",
  );
  await card(alice, "Project notes.md").locator(".file-title").click();
  await alice.locator("#detail-dialog").waitFor();
  assert.equal(await alice.locator("#detail-dialog img").count(), 0);
  assert.equal(await alice.evaluate(() => window.hacked), undefined);
  assert((await alice.locator(".detail-note").innerText()).includes("<img"));
  await alice.getByRole("button", { name: "Close", exact: true }).click();
  await until(
    () =>
      alice
        .locator(".toast")
        .count()
        .then((count) => count === 0),
    "notifications settling before screenshots",
  );
  await alice.screenshot({
    path: path.join(previews, "VaultShare-React-dashboard.png"),
    fullPage: true,
  });
  await noOverflow(alice);
  await alice.locator("#new-transfer").click();
  await alice.locator("#recipient").selectOption({ label: "Riya Sen (@riya)" });
  await alice.locator("#folder-input").setInputFiles(folder);
  await alice.screenshot({
    path: path.join(previews, "VaultShare-React-transfer.png"),
    fullPage: true,
  });
  await alice.getByRole("button", { name: "Close", exact: true }).click();
  await alice.setViewportSize({ width: 390, height: 844 });
  await noOverflow(alice);
  assert(
    await alice
      .locator(".hero")
      .evaluate((element) => element.scrollHeight <= element.clientHeight + 1),
    "Hero is clipped on mobile",
  );
  await alice.screenshot({
    path: path.join(previews, "VaultShare-React-mobile.png"),
    fullPage: true,
  });
  await alice.setViewportSize({ width: 1440, height: 1080 });
  await card(alice, "Project notes.md")
    .getByRole("button", { name: "Decline", exact: true })
    .click();
  await until(
    () =>
      card(alice, "Project notes.md")
        .innerText()
        .then((text) => text.includes("Declined")),
    "decline update",
  );
  await card(alice, "Brand assets.zip")
    .getByRole("button", { name: "Revoke access", exact: true })
    .click();
  await until(
    () =>
      card(bob, "Brand assets.zip")
        .innerText()
        .then((text) => text.includes("Revoked")),
    "revocation reflected in second session",
  );
  assert.equal(
    await card(bob, "Brand assets.zip")
      .getByRole("button", { name: "Download", exact: true })
      .count(),
    0,
  );
  await alice.locator("[data-page=activity]").click();
  assert(
    (await alice.locator("#activity-list").innerText()).includes(
      "Download verified and served",
    ),
  );
  assert(
    (await alice.locator("#activity-list").innerText()).includes(
      "Revoked access",
    ),
  );
  await bob.locator("#logout").click();
  await bob.locator("#auth-screen").waitFor();
  await until(
    () =>
      alice
        .locator("#people-list")
        .innerText()
        .then((text) => !text.includes("Riya Sen")),
    "logout presence",
  );
  expectedAuthExpiry = true;
  for (const session of app.locals.sessions.values()) {
    if (
      session.uid &&
      app.locals.store.state.users[session.uid].username === "abhishek"
    )
      session.expires = Date.now() / 1000 - 1;
  }
  await alice.locator("#auth-screen").waitFor();
  await alice.locator("#username").fill("abhishek");
  await alice.locator("#password").fill("a private passphrase 2026");
  await alice.locator("#auth-form button[type=submit]").click();
  await alice.locator("#app-screen").waitFor();
  assert.deepEqual(errors, []);
  console.log(
    "Browser flow passed: two accounts, live presence, folder approval, verified ZIP, bidirectional requests, escaping, revocation, logs, logout, expired-session recovery, desktop and mobile layouts.",
  );
} finally {
  await browser?.close();
  await new Promise((resolve) => server.close(resolve));
  fs.rmSync(temp, { recursive: true, force: true });
}

import { checkHost } from "../server/network.mjs";
const url = process.argv[2];
if (!url) {
  console.error("Usage: npm run check -- http://MAC_IP:8080");
  process.exitCode = 1;
} else
  try {
    await checkHost(url);
    console.log(`CONNECTED: ${url}\nVault Share React is responding.`);
  } catch (error) {
    console.error(`NOT CONNECTED: ${url}\n${error.message}`);
    process.exitCode = 1;
  }

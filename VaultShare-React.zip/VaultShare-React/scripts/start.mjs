import path from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "vite";
import { startHost } from "../server/index.mjs";
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
try {
  await build({ root });
  await startHost();
} catch (error) {
  console.error("Startup failed:", error.message);
  process.exitCode = 1;
}

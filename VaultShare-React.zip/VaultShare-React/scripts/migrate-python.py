#!/usr/bin/env python3
"""One-time Python-to-Node migration. Uses only Python's standard library."""
import argparse
import base64
import copy
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
from pathlib import Path

FIELDS = ('id','sender_id','recipient_id','name','kind','size','sha256','created_at','expires_at','file_count','entries')

def main():
    parser=argparse.ArgumentParser(description='Copy a stopped Python Vault Share vault into a fresh React workspace.')
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--target',type=Path,default=Path(__file__).resolve().parents[1]/'data')
    args=parser.parse_args()
    source,target=args.source.resolve(),args.target.resolve()
    if target.exists():
        parser.exit(1,'Target already exists. Migration only writes to a new folder; existing data is never overwritten.\n')
    temporary=None
    try:
        keys=(source/'keys.bin').read_bytes()
        if len(keys)!=64:raise ValueError('Invalid source encryption key.')
        envelope=json.loads((source/'state.json').read_text('utf-8'))
        mac=hmac.new(keys[32:],envelope['payload'].encode('utf-8'),hashlib.sha256).hexdigest()
        if not hmac.compare_digest(mac,envelope['mac']):raise ValueError('Source metadata integrity check failed.')
        state=json.loads(envelope['payload'])
        if state.get('version')!=1:raise ValueError('Source must be a Python Vault Share version-1 vault.')
        state['version']=2
        target.parent.mkdir(parents=True,exist_ok=True)
        temporary=target.parent/('.vault-migration-'+secrets.token_hex(12))
        temporary.mkdir(mode=0o700);(temporary/'blobs').mkdir(mode=0o700)
        (temporary/'keys.bin').write_bytes(keys);(temporary/'keys.bin').chmod(0o600)
        for tid,transfer in state['transfers'].items():
            if not re.fullmatch('[a-f0-9]{32}',tid) or transfer['id']!=tid:raise ValueError('Invalid source transfer ID.')
            fields={key:transfer[key] for key in FIELDS}
            aad=json.dumps(fields,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')
            transfer['legacy_aad']=base64.b64encode(aad).decode('ascii')
            transfer['legacy_fields']=copy.deepcopy(fields)
            if transfer['status'] in ('pending','accepted'):
                shutil.copyfile(source/'blobs'/(tid+'.vault'),temporary/'blobs'/(tid+'.vault'))
                (temporary/'blobs'/(tid+'.vault')).chmod(0o600)
        payload=json.dumps(state,sort_keys=True,separators=(',',':'),ensure_ascii=False)
        envelope={'payload':payload,'mac':hmac.new(keys[32:],payload.encode('utf-8'),hashlib.sha256).hexdigest()}
        (temporary/'state.json').write_text(json.dumps(envelope,ensure_ascii=False),'utf-8')
        (temporary/'state.json').chmod(0o600)
        os.rename(temporary,target)
        print(f"Migrated {len(state['users'])} accounts and {len(state['transfers'])} transfer records to {target}.\nSource data was left unchanged. Start React and sign in with your existing credentials.")
        return 0
    except Exception as error:
        if temporary and temporary.exists():shutil.rmtree(temporary)
        print(f'Migration failed: {error}')
        return 1

if __name__=='__main__':raise SystemExit(main())

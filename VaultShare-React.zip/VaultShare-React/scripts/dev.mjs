import { spawn } from "node:child_process";
import { createServer } from "vite";
const api = spawn(process.execPath, ["server/index.mjs", "--no-browser"], {
  stdio: "inherit",
});
let vite;
try {
  vite = await createServer();
  await vite.listen();
  vite.printUrls();
} catch (error) {
  console.error(error.message);
  api.kill();
  process.exitCode = 1;
}
api.on("exit", (code) => {
  if (code && vite) {
    vite.close();
    process.exitCode = code;
  }
});
for (const signal of ["SIGINT", "SIGTERM"])
  process.once(signal, () => {
    api.kill(signal);
    vite?.close();
  });

import crypto from "node:crypto";
import { promisify } from "node:util";
import { constantEqual } from "./store.mjs";
const scrypt = promisify(crypto.scrypt);
export class HttpError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}
export async function passwordHash(password) {
  const salt = crypto.randomBytes(12).toString("hex");
  const key = await scrypt(password, salt, 64, {
    N: 32768,
    r: 8,
    p: 1,
    maxmem: 128 * 1024 * 1024,
  });
  // Compatible with Werkzeug scrypt hashes, including migrated Python accounts.
  return `scrypt:32768:8:1$${salt}$${key.toString("hex")}`;
}
export async function passwordMatches(password, encoded) {
  const [method, salt, expected] = String(encoded).split("$");
  const [name, n, r, p] = method.split(":");
  if (
    name !== "scrypt" ||
    ![16384, 32768].includes(Number(n)) ||
    r !== "8" ||
    p !== "1" ||
    !salt ||
    !/^[a-f0-9]{128}$/.test(expected || "")
  )
    return false;
  const actual = await scrypt(password, salt, 64, {
    N: Number(n),
    r: 8,
    p: 1,
    maxmem: 128 * 1024 * 1024,
  });
  return constantEqual(actual.toString("hex"), expected);
}
export function safePath(value) {
  if (typeof value !== "string") throw new HttpError("Invalid file path.");
  value = value.normalize("NFC");
  if (
    !value ||
    Buffer.byteLength(value) > 800 ||
    value.startsWith("/") ||
    value.includes("\\")
  )
    throw new HttpError("Invalid file or folder path.");
  const reserved = /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)/i;
  const parts = value.split("/");
  for (const part of parts)
    if (
      ["", ".", ".."].includes(part) ||
      Buffer.byteLength(part) > 200 ||
      /[\x00-\x1f<>:"|?*]/.test(part) ||
      /[ .]$/.test(part) ||
      reserved.test(part)
    )
      throw new HttpError(
        "Use portable file names without special characters or parent paths.",
      );
  return parts.join("/");
}
export function validatePaths(values) {
  const paths = values.map(safePath);
  const normalized = paths.map((p) => p.toLocaleLowerCase("en-US"));
  const seen = new Set(normalized);
  if (seen.size !== paths.length)
    throw new HttpError("Duplicate file paths are not allowed.");
  if (
    normalized.some((p) =>
      p
        .split("/")
        .some((_, i, parts) => i > 0 && seen.has(parts.slice(0, i).join("/"))),
    )
  )
    throw new HttpError("A file path conflicts with a folder path.");
  return paths;
}

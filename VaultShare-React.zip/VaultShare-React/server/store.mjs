import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

export const id = () => crypto.randomBytes(16).toString("hex");
export const sha256 = (value) =>
  crypto.createHash("sha256").update(value).digest("hex");
export const now = () => Date.now() / 1000;
export function constantEqual(a, b) {
  const left = Buffer.from(String(a)),
    right = Buffer.from(String(b));
  return left.length === right.length && crypto.timingSafeEqual(left, right);
}
export function stable(value) {
  if (Array.isArray(value)) return value.map(stable);
  if (value && typeof value === "object")
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((k) => [k, stable(value[k])]),
    );
  return value;
}
const immutableKeys = [
  "id",
  "sender_id",
  "recipient_id",
  "name",
  "kind",
  "size",
  "sha256",
  "created_at",
  "expires_at",
  "file_count",
  "entries",
];
export const immutable = (record) =>
  Object.fromEntries(immutableKeys.map((k) => [k, record[k]]));
export class IntegrityError extends Error {}

export class Store {
  constructor(directory) {
    this.root = path.resolve(directory);
    this.blobs = path.join(this.root, "blobs");
    fs.mkdirSync(this.blobs, { recursive: true, mode: 0o700 });
    this.statePath = path.join(this.root, "state.json");
    const keyPath = path.join(this.root, "keys.bin");
    if (!fs.existsSync(keyPath)) {
      if (fs.existsSync(this.statePath) || fs.readdirSync(this.blobs).length)
        throw new Error(
          "Encryption key missing. Restore keys.bin from a trusted backup.",
        );
      this.atomic(keyPath, crypto.randomBytes(64), true);
    }
    this.keys = fs.readFileSync(keyPath);
    if (this.keys.length !== 64)
      throw new Error("Invalid keys.bin. Restore a trusted backup.");
    if (fs.existsSync(this.statePath)) {
      const envelope = JSON.parse(fs.readFileSync(this.statePath, "utf8"));
      if (
        typeof envelope.payload !== "string" ||
        !constantEqual(this.mac(envelope.payload), envelope.mac)
      )
        throw new Error(
          "Metadata integrity verification failed. Restore a trusted backup.",
        );
      this.state = JSON.parse(envelope.payload);
      if (this.state.version !== 2)
        throw new Error(
          "Python data requires the included one-time migration script. Do not replace or delete keys.bin.",
        );
    } else {
      if (fs.readdirSync(this.blobs).some((name) => name.endsWith(".vault")))
        throw new Error(
          "Metadata missing while encrypted files exist. Restore state.json.",
        );
      this.state = { version: 2, users: {}, transfers: {}, logs: [] };
      this.save();
    }
    const references = new Set(Object.keys(this.state.transfers));
    for (const name of fs.readdirSync(this.blobs))
      if (
        name.endsWith(".part") ||
        (name.endsWith(".vault") && !references.has(name.slice(0, -6)))
      )
        fs.unlinkSync(path.join(this.blobs, name));
  }
  atomic(filename, data, exclusive = false) {
    const temporary = filename + ".part";
    const fd = fs.openSync(temporary, "w", 0o600);
    try {
      fs.writeFileSync(fd, data);
      fs.fsyncSync(fd);
    } finally {
      fs.closeSync(fd);
    }
    if (exclusive && fs.existsSync(filename)) {
      fs.unlinkSync(temporary);
      throw new Error("Key file already exists.");
    }
    fs.renameSync(temporary, filename);
  }
  mac(payload) {
    return crypto
      .createHmac("sha256", this.keys.subarray(32))
      .update(payload)
      .digest("hex");
  }
  save() {
    const payload = JSON.stringify(stable(this.state));
    this.atomic(
      this.statePath,
      JSON.stringify({ payload, mac: this.mac(payload) }),
    );
  }
  transaction(fn) {
    const before = structuredClone(this.state);
    try {
      const result = fn(this.state);
      this.save();
      return result;
    } catch (error) {
      this.state = before;
      throw error;
    }
  }
  log(action, actor, participants = [actor], transfer = null, detail = "") {
    this.state.logs.push({
      id: id(),
      action,
      actor,
      participants,
      transfer_id: transfer,
      detail: String(detail).slice(0, 300),
      at: now(),
    });
    this.state.logs = this.state.logs.slice(-10000);
  }
  aad(record) {
    const fields = immutable(record);
    if (record.legacy_aad) {
      if (
        JSON.stringify(stable(fields)) !==
        JSON.stringify(stable(record.legacy_fields))
      )
        throw new IntegrityError("Imported immutable metadata changed.");
      return Buffer.from(record.legacy_aad, "base64");
    }
    return Buffer.from(JSON.stringify(stable(fields)));
  }
  encrypt(record, payload) {
    const nonce = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv(
      "aes-256-gcm",
      this.keys.subarray(0, 32),
      nonce,
      { authTagLength: 16 },
    );
    cipher.setAAD(this.aad(record));
    const ciphertext = Buffer.concat([cipher.update(payload), cipher.final()]);
    const encrypted = Buffer.concat([
      Buffer.from("VS01"),
      nonce,
      ciphertext,
      cipher.getAuthTag(),
    ]);
    this.atomic(path.join(this.blobs, record.id + ".vault"), encrypted);
  }
  decrypt(record) {
    try {
      const data = fs.readFileSync(path.join(this.blobs, record.id + ".vault"));
      if (data.length < 32 || data.subarray(0, 4).toString() !== "VS01")
        throw new Error("Invalid payload");
      const decipher = crypto.createDecipheriv(
        "aes-256-gcm",
        this.keys.subarray(0, 32),
        data.subarray(4, 16),
        { authTagLength: 16 },
      );
      decipher.setAAD(this.aad(record));
      decipher.setAuthTag(data.subarray(-16));
      const payload = Buffer.concat([
        decipher.update(data.subarray(16, -16)),
        decipher.final(),
      ]);
      if (!constantEqual(sha256(payload), record.sha256))
        throw new Error("SHA-256 mismatch");
      return payload;
    } catch (error) {
      throw new IntegrityError(
        "Stored payload failed authentication or SHA-256 verification.",
        { cause: error },
      );
    }
  }
  deleteBlob(transferId) {
    fs.rmSync(path.join(this.blobs, transferId + ".vault"), { force: true });
  }
  expire() {
    const due = Object.values(this.state.transfers).filter(
      (t) =>
        ["pending", "accepted"].includes(t.status) && t.expires_at <= now(),
    );
    if (due.length)
      this.transaction(() => {
        for (const t of due) {
          t.status = "expired";
          this.log(
            "expired",
            t.sender_id,
            [t.sender_id, t.recipient_id],
            t.id,
            t.name,
          );
        }
      });
    for (const t of Object.values(this.state.transfers))
      if (["expired", "declined", "revoked", "corrupt"].includes(t.status))
        this.deleteBlob(t.id);
  }
}

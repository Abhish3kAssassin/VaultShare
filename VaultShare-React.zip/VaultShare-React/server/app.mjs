import express from "express";
import multer from "multer";
import JSZip from "jszip";
import path from "node:path";
import fs from "node:fs";
import crypto from "node:crypto";
import {
  Store,
  id,
  now,
  sha256,
  constantEqual,
  IntegrityError,
} from "./store.mjs";
import {
  HttpError,
  passwordHash,
  passwordMatches,
  validatePaths,
} from "./security.mjs";

export async function createApp({
  dataDir,
  maxUploadMB = 128,
  quotaMB = 2048,
  distDir,
} = {}) {
  const app = express(),
    store = new Store(dataDir),
    sessions = new Map(),
    attempts = new Map();
  const maxBytes = maxUploadMB * 1024 * 1024,
    quotaBytes = quotaMB * 1024 * 1024;
  const dummyHash = await passwordHash(crypto.randomBytes(24).toString("hex"));
  let activeUploads = 0;
  app.disable("x-powered-by");
  app.locals.store = store;
  app.locals.sessions = sessions;
  const publicUser = (uid) => {
    const u = store.state.users[uid];
    return { id: uid, username: u.username, display_name: u.display_name };
  };
  function transferView(t, uid) {
    return {
      ...Object.fromEntries(
        [
          "id",
          "name",
          "kind",
          "size",
          "file_count",
          "sha256",
          "created_at",
          "expires_at",
          "status",
          "note",
          "downloads",
          "accepted_at",
          "entries",
        ].map((k) => [k, t[k]]),
      ),
      sender: publicUser(t.sender_id),
      recipient: publicUser(t.recipient_id),
      direction: t.sender_id === uid ? "outgoing" : "incoming",
    };
  }
  function readSession(req) {
    const cookie = String(req.headers.cookie || "")
      .split(";")
      .map((s) => s.trim())
      .find((s) => s.startsWith("vaultshare_react_session="));
    const token = cookie?.slice("vaultshare_react_session=".length);
    const session = token ? sessions.get(token) : null;
    if (session && session.expires > now()) return { token, session };
    if (token) sessions.delete(token);
    return { token: null, session: null };
  }
  function newSession(req, res, uid = null) {
    if (req.sessionToken) sessions.delete(req.sessionToken);
    if (sessions.size >= 5000)
      throw new HttpError("Too many active sessions. Try again later.", 429);
    const token = crypto.randomBytes(32).toString("base64url");
    const session = {
      uid,
      csrf: crypto.randomBytes(32).toString("base64url"),
      seen: now(),
      expires: now() + (uid ? 12 * 3600 : 1800),
    };
    sessions.set(token, session);
    req.session = session;
    req.sessionToken = token;
    res.cookie("vaultshare_react_session", token, {
      httpOnly: true,
      sameSite: "strict",
      secure: false,
      path: "/",
    });
    return session;
  }
  function limited(key, limit, window) {
    const current = now(),
      queue = (attempts.get(key) || []).filter((t) => t > current - window);
    if (queue.length >= limit) return false;
    queue.push(current);
    attempts.set(key, queue);
    if (attempts.size > 5000)
      for (const [key, value] of attempts)
        if (value.at(-1) < current - 3600) attempts.delete(key);
    return true;
  }
  function required(req, _res, next) {
    if (!req.session?.uid)
      return next(new HttpError("Please sign in to continue.", 401));
    req.session.seen = now();
    req.uid = req.session.uid;
    next();
  }
  app.use((req, res, next) => {
    res.set({
      "X-Content-Type-Options": "nosniff",
      "X-Frame-Options": "DENY",
      "Referrer-Policy": "no-referrer",
      "Content-Security-Policy":
        "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",
      "Cache-Control": "no-store",
    });
    try {
      for (const [token, s] of sessions)
        if (s.expires <= now()) sessions.delete(token);
      const current = readSession(req);
      req.session = current.session;
      req.sessionToken = current.token;
      if (req.path.startsWith("/api/")) store.expire();
      if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
        if (
          !req.session ||
          !constantEqual(req.session.csrf, req.get("X-CSRF-Token") || "")
        )
          throw new HttpError(
            "Session verification failed. Reload the page.",
            403,
          );
        if (
          req.get("Origin") &&
          req.get("Origin") !== `http://${req.get("Host")}`
        )
          throw new HttpError("Cross-origin requests are not allowed.", 403);
      }
      next();
    } catch (error) {
      next(error);
    }
  });
  app.use(express.json({ limit: "64kb" }));
  app.get("/healthz", (_req, res) =>
    res.json({ service: "Vault Share", status: "ready", edition: "React" }),
  );
  app.get("/api/session", (req, res) => {
    const session = req.session || newSession(req, res);
    res.json({
      user: session.uid ? publicUser(session.uid) : null,
      csrf: session.csrf,
      max_upload_mb: maxUploadMB,
      secure_transport: false,
    });
  });
  app.post("/api/register", async (req, res) => {
    if (!limited(`register:${req.socket.remoteAddress}`, 20, 3600))
      throw new HttpError("Too many account requests. Try again later.", 429);
    const data = req.body || {},
      username = String(data.username || "")
        .trim()
        .toLowerCase(),
      name = String(data.display_name || "").trim();
    if (!/^[a-z0-9_]{3,24}$/.test(username))
      throw new HttpError(
        "Username: 3–24 lowercase letters, numbers, or underscores.",
      );
    if (!name || name.length > 48 || /[\x00-\x1f]/.test(name))
      throw new HttpError("Enter a display name of 1–48 characters.");
    if (
      typeof data.password !== "string" ||
      data.password.length < 12 ||
      data.password.length > 256
    )
      throw new HttpError("Use a password of 12–256 characters.");
    const hash = await passwordHash(data.password);
    const uid = store.transaction((state) => {
      if (Object.values(state.users).some((u) => u.username === username))
        throw new HttpError("This username is already taken.", 409);
      if (Object.keys(state.users).length >= 1000)
        throw new HttpError("This vault has reached its account limit.", 409);
      const uid = id();
      state.users[uid] = {
        username,
        display_name: name,
        password_hash: hash,
        created_at: now(),
      };
      store.log("registered", uid);
      return uid;
    });
    const session = newSession(req, res, uid);
    res.status(201).json({ user: publicUser(uid), csrf: session.csrf });
  });
  app.post("/api/login", async (req, res) => {
    const data = req.body || {},
      username = String(data.username || "")
        .trim()
        .toLowerCase()
        .slice(0, 24);
    if (typeof data.password !== "string" || data.password.length > 256)
      throw new HttpError("Invalid username or password.", 401);
    if (
      !limited(`login-ip:${req.socket.remoteAddress}`, 40, 900) ||
      !limited(`login-user:${username}`, 15, 900)
    )
      throw new HttpError(
        "Too many sign-in attempts. Try again in 15 minutes.",
        429,
      );
    const found = Object.entries(store.state.users).find(
      ([, u]) => u.username === username,
    );
    const okay = await passwordMatches(
      data.password,
      found?.[1].password_hash || dummyHash,
    );
    if (!okay || !found)
      throw new HttpError("Invalid username or password.", 401);
    const uid = found[0],
      session = newSession(req, res, uid);
    store.transaction(() => store.log("signed_in", uid));
    res.json({ user: publicUser(uid), csrf: session.csrf });
  });
  app.post("/api/logout", required, (req, res) => {
    store.transaction(() => store.log("signed_out", req.uid));
    const session = newSession(req, res);
    res.json({ ok: true, csrf: session.csrf });
  });
  app.get("/api/dashboard", required, (req, res) => {
    const online = new Set(
      [...sessions.values()]
        .filter((s) => s.uid && s.seen > now() - 35 && s.expires > now())
        .map((s) => s.uid),
    );
    online.delete(req.uid);
    res.json({
      users: [...online]
        .map(publicUser)
        .sort((a, b) => a.display_name.localeCompare(b.display_name)),
      transfers: Object.values(store.state.transfers)
        .filter((t) => [t.sender_id, t.recipient_id].includes(req.uid))
        .map((t) => transferView(t, req.uid))
        .sort((a, b) => b.created_at - a.created_at),
      logs: store.state.logs
        .filter((l) => l.participants.includes(req.uid))
        .slice(-150)
        .reverse()
        .map((l) => ({
          ...l,
          actor_name: store.state.users[l.actor]?.display_name || "System",
        })),
      server_time: now(),
    });
  });
  const storage = {
    _handleFile(req, file, callback) {
      const chunks = [];
      let size = 0,
        done = false;
      file.stream.on("data", (chunk) => {
        if (done) return;
        size += chunk.length;
        req.uploadBytes = (req.uploadBytes || 0) + chunk.length;
        if (req.uploadBytes > maxBytes) {
          done = true;
          callback(
            new HttpError(`Choose at most ${maxUploadMB} MB of files.`, 413),
          );
          return;
        }
        chunks.push(chunk);
      });
      file.stream.on("end", () => {
        if (!done) {
          done = true;
          callback(null, { buffer: Buffer.concat(chunks), size });
        }
      });
      file.stream.on("error", (error) => {
        if (!done) {
          done = true;
          callback(error);
        }
      });
    },
    _removeFile(_req, file, callback) {
      delete file.buffer;
      callback(null);
    },
  };
  const uploader = multer({
    storage,
    limits: {
      files: 2000,
      fields: 4,
      parts: 2004,
      fieldSize: 256 * 1024,
      fileSize: maxBytes,
    },
  }).array("files", 2000);
  app.post(
    "/api/transfers",
    required,
    (req, res, next) => {
      if (activeUploads >= 2)
        return next(
          new HttpError(
            "The vault is handling other uploads. Try again shortly.",
            429,
          ),
        );
      activeUploads++;
      let released = false;
      const release = () => {
        if (!released) {
          released = true;
          activeUploads--;
        }
      };
      res.on("finish", release);
      res.on("close", release);
      uploader(req, res, next);
    },
    async (req, res) => {
      const recipient = req.body.recipient_id,
        hours = Number(req.body.expiry_hours),
        note = String(req.body.note || "").trim();
      if (![1, 6, 24, 72, 168].includes(hours))
        throw new HttpError("Choose a valid expiry window.");
      if (note.length > 280)
        throw new HttpError("Keep your message under 280 characters.");
      if (!store.state.users[recipient] || recipient === req.uid)
        throw new HttpError("Choose another user as the receiver.");
      let rawPaths;
      try {
        rawPaths = JSON.parse(req.body.paths || "[]");
      } catch {
        throw new HttpError("Invalid folder manifest.");
      }
      if (
        !Array.isArray(rawPaths) ||
        !req.files?.length ||
        rawPaths.length !== req.files.length
      )
        throw new HttpError("Choose 1–2000 files with a path for each.");
      const paths = validatePaths(rawPaths),
        entries = req.files.map((f, i) => ({
          path: paths[i],
          size: f.size,
          sha256: sha256(f.buffer),
        }));
      const bundle = req.files.length > 1 || paths.some((p) => p.includes("/"));
      let payload, name;
      if (bundle) {
        const zip = new JSZip();
        req.files.forEach((f, i) => zip.file(paths[i], f.buffer));
        payload = await zip.generateAsync({
          type: "nodebuffer",
          compression: "DEFLATE",
          compressionOptions: { level: 3 },
        });
        const roots = new Set(paths.map((p) => p.split("/")[0]));
        name =
          (roots.size === 1 && paths[0].includes("/")
            ? [...roots][0]
            : "Shared files") + ".zip";
      } else {
        payload = req.files[0].buffer;
        name = paths[0];
      }
      const created = now(),
        t = {
          id: id(),
          sender_id: req.uid,
          recipient_id: recipient,
          name,
          kind: paths.some((p) => p.includes("/"))
            ? "folder"
            : bundle
              ? "bundle"
              : "file",
          size: payload.length,
          file_count: entries.length,
          entries,
          sha256: sha256(payload),
          created_at: created,
          expires_at: created + hours * 3600,
          status: "pending",
          note,
          downloads: 0,
          accepted_at: null,
        };
      const live = Object.values(store.state.transfers).filter((t) =>
        ["pending", "accepted"].includes(t.status),
      );
      if (live.reduce((s, t) => s + t.size, 0) + t.size > quotaBytes)
        throw new HttpError(
          "The vault is full. Revoke older transfers or wait for expiry.",
          507,
        );
      if (
        live
          .filter((t) => t.sender_id === req.uid)
          .reduce((s, t) => s + t.size, 0) +
          t.size >
        Math.min(quotaBytes, 512 * 1024 * 1024)
      )
        throw new HttpError(
          "Your active transfers have reached the 512 MB storage limit.",
          507,
        );
      if (
        live.filter((t) => t.sender_id === req.uid).length >= 100 ||
        live.length >= 500
      )
        throw new HttpError("The active transfer limit has been reached.", 429);
      try {
        store.encrypt(t, payload);
        store.transaction((state) => {
          state.transfers[t.id] = t;
          const terminal = Object.values(state.transfers)
            .filter((t) => !["pending", "accepted"].includes(t.status))
            .sort((a, b) => a.created_at - b.created_at);
          for (const old of terminal.slice(0, -3000))
            delete state.transfers[old.id];
          store.log("requested", req.uid, [req.uid, recipient], t.id, name);
        });
      } catch (error) {
        store.deleteBlob(t.id);
        throw error;
      }
      res.status(201).json({ transfer: transferView(t, req.uid) });
    },
  );
  app.post("/api/transfers/:transferId/:action", required, (req, res) => {
    const { transferId, action } = req.params;
    if (!["accept", "decline", "revoke"].includes(action))
      throw new HttpError("Unknown action.", 404);
    const t = store.state.transfers[transferId];
    if (!t || ![t.sender_id, t.recipient_id].includes(req.uid))
      throw new HttpError("Transfer not found.", 404);
    if (
      (action === "revoke" && t.sender_id !== req.uid) ||
      (action !== "revoke" && t.recipient_id !== req.uid)
    )
      throw new HttpError("You cannot perform this action.", 403);
    if (
      !(action === "revoke" ? ["pending", "accepted"] : ["pending"]).includes(
        t.status,
      ) ||
      t.expires_at <= now()
    )
      throw new HttpError(
        "This transfer is no longer available for that action.",
        409,
      );
    store.transaction(() => {
      t.status = { accept: "accepted", decline: "declined", revoke: "revoked" }[
        action
      ];
      if (action === "accept") t.accepted_at = now();
      store.log(t.status, req.uid, [t.sender_id, t.recipient_id], t.id, t.name);
    });
    if (action !== "accept") store.deleteBlob(t.id);
    res.json({ transfer: transferView(t, req.uid) });
  });
  app.get("/api/transfers/:transferId/download", required, (req, res) => {
    const t = store.state.transfers[req.params.transferId];
    if (!t || t.recipient_id !== req.uid)
      throw new HttpError("Transfer not found.", 404);
    if (t.status !== "accepted" || t.expires_at <= now())
      throw new HttpError(
        "Accept the request before downloading. Expired or revoked files are unavailable.",
        403,
      );
    let payload;
    try {
      payload = store.decrypt(t);
    } catch (error) {
      if (!(error instanceof IntegrityError)) throw error;
      store.transaction(() => {
        t.status = "corrupt";
        store.log(
          "integrity_failed",
          req.uid,
          [t.sender_id, t.recipient_id],
          t.id,
          t.name,
        );
      });
      store.deleteBlob(t.id);
      throw new HttpError(
        "Integrity verification failed. Download blocked; ask the sender to resend.",
        409,
      );
    }
    if (t.expires_at <= now())
      throw new HttpError("The transfer expired during verification.", 403);
    store.transaction(() => {
      t.downloads++;
      store.log(
        "download_verified",
        req.uid,
        [t.sender_id, t.recipient_id],
        t.id,
        t.name,
      );
    });
    res
      .set({
        "X-VaultShare-SHA256": t.sha256,
        "X-VaultShare-Integrity": "verified",
      })
      .attachment(t.name)
      .type("application/octet-stream")
      .send(payload);
  });
  app.use("/api", (_req, _res, next) =>
    next(new HttpError("Endpoint not found.", 404)),
  );
  if (distDir && fs.existsSync(path.join(distDir, "index.html"))) {
    app.use(express.static(distDir, { index: false, maxAge: "1h" }));
    app.get("/", (_req, res) => res.sendFile(path.join(distDir, "index.html")));
  } else
    app.get("/", (_req, res) =>
      res
        .status(503)
        .type("text")
        .send(
          "React UI is not built yet. Run npm start to build and serve it.",
        ),
    );
  app.use((_req, _res, next) => next(new HttpError("Page not found.", 404)));
  app.use((error, _req, res, _next) => {
    if (res.headersSent) return;
    const malformedMultipart =
      /^(Malformed part header|Unexpected end of form|Multipart: Boundary not found)$/.test(
        error.message,
      );
    const status =
      error instanceof multer.MulterError
        ? 413
        : malformedMultipart
          ? 400
          : error.status || 500;
    if (status === 500) console.error("Request failed:", error.message);
    res
      .status(status)
      .json({
        error:
          error instanceof multer.MulterError
            ? "Upload limit reached. Choose fewer or smaller files."
            : status === 500
              ? "The server could not complete this request. Check the host console."
              : error.message,
      });
  });
  return app;
}

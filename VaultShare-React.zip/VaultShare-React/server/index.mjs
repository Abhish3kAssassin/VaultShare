import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { spawn } from "node:child_process";
import lockfile from "proper-lockfile";
import { createApp } from "./app.mjs";
import { lanInterfaces, checkHost } from "./network.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export async function startHost(argv = process.argv.slice(2)) {
  const { values } = parseArgs({
    args: argv,
    options: {
      port: { type: "string" },
      host: { type: "string" },
      "data-dir": { type: "string" },
      "no-browser": { type: "boolean", default: false },
      "max-upload-mb": { type: "string" },
      "quota-mb": { type: "string" },
    },
    strict: true,
  });
  const port = Number(values.port ?? process.env.VS_PORT ?? 8080),
    host = values.host ?? process.env.VS_HOST ?? "0.0.0.0";
  const dataDir = path.resolve(
    values["data-dir"] ?? process.env.VS_DATA_DIR ?? path.join(root, "data"),
  );
  const maxUploadMB = Number(values["max-upload-mb"] ?? 128),
    quotaMB = Number(values["quota-mb"] ?? 2048);
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("Port must be 1–65535.");
  if (
    !Number.isInteger(maxUploadMB) ||
    maxUploadMB < 1 ||
    maxUploadMB > 256 ||
    !Number.isFinite(quotaMB) ||
    quotaMB < maxUploadMB
  )
    throw new Error(
      "Upload limit must be 1–256 MB and quota must cover one transfer.",
    );
  if (host !== "localhost" && !/^\d{1,3}(\.\d{1,3}){3}$/.test(host))
    throw new Error("Host must be localhost or an IPv4 address.");
  fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  let release, server;
  try {
    release = await lockfile.lock(dataDir, {
      retries: 0,
      stale: 30000,
      update: 10000,
      onCompromised(error) {
        console.error("Host lock lost:", error.message);
        server?.close();
        process.exitCode = 1;
      },
    });
    const app = await createApp({
      dataDir,
      maxUploadMB,
      quotaMB,
      distDir: path.join(root, "dist"),
    });
    server = http.createServer(app);
    await new Promise((resolve, reject) => {
      server.once("error", reject);
      server.listen(port, host === "localhost" ? "127.0.0.1" : host, resolve);
    });
    const localAddress =
      host === "0.0.0.0" || host === "localhost" ? "127.0.0.1" : host;
    const localURL = `http://${localAddress}:${port}`;
    await checkHost(localURL);
    console.log("\nVAULT SHARE REACT IS READY — local HTTP check passed.");
    console.log(`\nOn this computer: ${localURL}`);
    if (host === "0.0.0.0") {
      const interfaces = lanInterfaces();
      console.log("\nOn Windows / other LAN devices:");
      if (!interfaces.length)
        console.log(
          "  No LAN address detected. Find this host’s Wi-Fi/Ethernet IPv4 address manually.",
        );
      for (const item of interfaces)
        console.log(
          `  http://${item.address}:${port}  (${item.name}${item.virtual ? "; VPN/virtual — prefer Wi-Fi/Ethernet" : ""})`,
        );
    } else
      console.log(
        "\nBound to a specific address. Use --host 0.0.0.0 for all LAN interfaces.",
      );
    console.log(
      "\nKeep this terminal open. Stop with Ctrl+C.\nHTTP traffic is not encrypted; stored files use AES-256-GCM.\n",
    );
    const sweep = setInterval(() => {
      try {
        app.locals.store.expire();
      } catch (error) {
        console.error("Expiry cleanup failed:", error.message);
      }
    }, 30000);
    sweep.unref();
    let closing = false;
    const close = async () => {
      if (closing) return;
      closing = true;
      clearInterval(sweep);
      await new Promise((resolve) => server.close(resolve));
      await release();
    };
    for (const signal of ["SIGINT", "SIGTERM"])
      process.once(signal, () => {
        close().catch(console.error);
      });
    if (!values["no-browser"]) {
      const command =
        process.platform === "darwin"
          ? ["open", [localURL]]
          : process.platform === "win32"
            ? ["rundll32", ["url.dll,FileProtocolHandler", localURL]]
            : ["xdg-open", [localURL]];
      const browser = spawn(command[0], command[1], {
        stdio: "ignore",
        detached: true,
      });
      browser.on("error", () => {});
      browser.unref();
    }
    return { app, server, close, localURL };
  } catch (error) {
    if (server?.listening)
      await new Promise((resolve) => server.close(resolve));
    if (release) await release();
    if (error.code === "ELOCKED")
      throw new Error(
        "Another host is using this data folder. Stop it before starting this one.",
      );
    if (error.code === "EADDRINUSE")
      throw new Error(
        `Port ${port} is occupied. Stop the previous Python/Node app or use npm start -- --port 8081.`,
      );
    throw error;
  }
}
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
)
  startHost().catch((error) => {
    console.error(`Vault Share could not start: ${error.message}`);
    process.exitCode = 1;
  });

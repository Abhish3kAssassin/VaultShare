import os from "node:os";
import http from "node:http";
const virtual =
  /^(utun|tun|tap|tailscale|wg|docker|veth|vmnet|vbox|bridge|br-|loopback)/i;
export function lanInterfaces(source) {
  if (!source) {
    try {
      source = os.networkInterfaces();
    } catch {
      return [];
    }
  }
  const found = [];
  for (const [name, addresses] of Object.entries(source))
    for (const address of addresses || []) {
      if (
        address.family !== "IPv4" ||
        address.internal ||
        address.address === "0.0.0.0"
      )
        continue;
      if (found.some((item) => item.address === address.address)) continue;
      found.push({
        name,
        address: address.address,
        virtual: virtual.test(name),
      });
    }
  return found.sort(
    (a, b) =>
      Number(a.virtual) - Number(b.virtual) || a.name.localeCompare(b.name),
  );
}
export function checkHost(url) {
  return new Promise((resolve, reject) => {
    const target = new URL("/healthz", url);
    if (target.protocol !== "http:" || target.username || target.password)
      return reject(new Error("Use an HTTP host address without credentials."));
    const request = http.get(target, { timeout: 3000 }, (res) => {
      let data = "";
      res.on("data", (chunk) => {
        data += chunk;
        if (data.length > 2048)
          request.destroy(new Error("Unexpected health response."));
      });
      res.on("end", () => {
        try {
          const value = JSON.parse(data);
          if (
            res.statusCode !== 200 ||
            value.service !== "Vault Share" ||
            value.edition !== "React"
          )
            throw new Error("This address does not serve Vault Share React.");
          resolve(value);
        } catch (error) {
          reject(error);
        }
      });
    });
    request.on("timeout", () =>
      request.destroy(new Error("Connection timed out.")),
    );
    request.on("error", reject);
  });
}

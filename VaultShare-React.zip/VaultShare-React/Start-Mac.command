#!/bin/bash
cd -- "$(dirname -- "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22.12 or newer from https://nodejs.org/ and try again."
  read -r -p "Press Enter to close. "
  exit 1
fi
if [ ! -d node_modules ]; then
  npm ci || exit 1
fi
npm start -- "$@"
status=$?
if [ "$status" -ne 0 ]; then read -r -p "Press Enter to close. "; fi
exit "$status"

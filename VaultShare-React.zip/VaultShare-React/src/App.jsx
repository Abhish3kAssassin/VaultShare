import { useCallback, useEffect, useRef, useState } from "react";
import { request, setCSRF, upload, downloadTransfer } from "./api";
import AuthPage from "./components/AuthPage";
import Dashboard from "./components/Dashboard";
import { SendModal, DetailModal, SecurityModal } from "./components/Modals";
const empty = { users: [], transfers: [], logs: [] };
export default function App() {
  const [user, setUser] = useState(null),
    [loading, setLoading] = useState(true),
    [bootError, setBootError] = useState(""),
    [data, setData] = useState(empty),
    [connected, setConnected] = useState(true),
    [offset, setOffset] = useState(0),
    [maxUpload, setMaxUpload] = useState(128);
  const [modal, setModal] = useState(null),
    [toasts, setToasts] = useState([]),
    [busyIds, setBusyIds] = useState(new Set()),
    [downloadIds, setDownloadIds] = useState(new Set());
  const generation = useRef(0),
    pending = useRef(null),
    alive = useRef(true),
    toastTimers = useRef(new Set());
  const toast = useCallback((message, kind = "") => {
    if (!alive.current) return;
    const id = Date.now() + Math.random();
    setToasts((list) => [...list, { id, message, kind }]);
    const timer = setTimeout(() => {
      if (alive.current) setToasts((list) => list.filter((t) => t.id !== id));
      toastTimers.current.delete(timer);
    }, 6500);
    toastTimers.current.add(timer);
  }, []);
  useEffect(() => {
    let ignore = false;
    request("/api/session")
      .then((initial) => {
        if (ignore) return;
        setCSRF(initial.csrf);
        setUser(initial.user);
        setMaxUpload(initial.max_upload_mb);
      })
      .catch((error) => {
        if (!ignore) setBootError(error.message);
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });
    return () => {
      ignore = true;
    };
  }, []);
  useEffect(
    () => () => {
      alive.current = false;
      toastTimers.current.forEach(clearTimeout);
    },
    [],
  );
  const refresh = useCallback(async () => {
    if (!user) return;
    const current = ++generation.current;
    try {
      const next = await request("/api/dashboard");
      if (current !== generation.current || !alive.current) return;
      setConnected(true);
      setOffset(next.server_time - Date.now() / 1000);
      const incoming = new Set(
        next.transfers
          .filter((t) => t.direction === "incoming" && t.status === "pending")
          .map((t) => t.id),
      );
      if (
        pending.current &&
        [...incoming].some((id) => !pending.current.has(id))
      )
        toast("A new transfer request is waiting for your approval.");
      pending.current = incoming;
      setData(next);
    } catch (error) {
      if (current !== generation.current || !alive.current) return;
      if (error.status === 401) {
        setUser(null);
        setModal(null);
        toast("Your session ended. Please sign in again.");
      } else {
        setConnected(false);
        setData((previous) => ({ ...previous, users: [] }));
      }
    }
  }, [user?.id, toast]);
  useEffect(() => {
    pending.current = null;
    setData(empty);
    if (!user) return;
    refresh();
    const timer = setInterval(refresh, 5000);
    return () => {
      clearInterval(timer);
      generation.current++;
    };
  }, [refresh]);
  async function authenticate(mode, fields) {
    const session = await request("/api/session");
    setCSRF(session.csrf);
    setMaxUpload(session.max_upload_mb);
    const next = await request(`/api/${mode}`, {
      method: "POST",
      body: fields,
    });
    setCSRF(next.csrf);
    setUser(next.user);
  }
  async function logout() {
    try {
      const next = await request("/api/logout", { method: "POST", body: {} });
      setCSRF(next.csrf);
      generation.current++;
      setUser(null);
      setModal(null);
    } catch (error) {
      toast(error.message, "error");
    }
  }
  async function send(data, progress) {
    await upload(data, progress);
    toast("Request sent. Your receiver will approve access.", "success");
    await refresh();
  }
  async function decide(id, action) {
    setBusyIds((ids) => new Set([...ids, id]));
    try {
      await request(`/api/transfers/${id}/${action}`, {
        method: "POST",
        body: {},
      });
      toast(
        {
          accept: "Request accepted. Your files are ready to download.",
          decline: "Request declined. The encrypted payload has been removed.",
          revoke: "Access revoked. Future downloads are blocked.",
        }[action],
        "success",
      );
      await refresh();
    } catch (error) {
      toast(error.message, "error");
    } finally {
      setBusyIds((ids) => {
        const next = new Set(ids);
        next.delete(id);
        return next;
      });
    }
  }
  async function download(transfer) {
    if (downloadIds.has(transfer.id)) return;
    setDownloadIds((ids) => new Set([...ids, transfer.id]));
    try {
      const verified = await downloadTransfer(transfer);
      toast(
        verified
          ? "SHA-256 verified. Your download is ready."
          : "Server integrity verified. Your download is ready.",
        "success",
      );
      await refresh();
    } catch (error) {
      toast(error.message, "error");
    } finally {
      setDownloadIds((ids) => {
        const next = new Set(ids);
        next.delete(transfer.id);
        return next;
      });
    }
  }
  const detail =
    modal?.type === "detail"
      ? data.transfers.find((t) => t.id === modal.id)
      : null;
  return (
    <>
      {loading ? (
        <div className="loading">
          <div className="brand-mark">V</div>
          <p>Opening your vault…</p>
        </div>
      ) : bootError ? (
        <div className="loading">
          <p>Could not open Vault Share: {bootError}</p>
          <button className="button primary" onClick={() => location.reload()}>
            Try again
          </button>
        </div>
      ) : user ? (
        <Dashboard
          user={user}
          data={data}
          connected={connected}
          offset={offset}
          onSend={(uid) => setModal({ type: "send", uid })}
          onLogout={logout}
          onSecurity={() => setModal({ type: "security" })}
          onDetail={(id) => setModal({ type: "detail", id })}
          onDecision={decide}
          onDownload={download}
          busyIds={busyIds}
          downloadIds={downloadIds}
        />
      ) : (
        <AuthPage onAuthenticate={authenticate} />
      )}
      {user && modal?.type === "send" && (
        <SendModal
          users={data.users}
          maxUpload={maxUpload}
          initialRecipient={modal.uid}
          onClose={() => setModal(null)}
          onSend={send}
        />
      )}
      {user && detail && (
        <DetailModal transfer={detail} onClose={() => setModal(null)} />
      )}{" "}
      {user && modal?.type === "security" && (
        <SecurityModal onClose={() => setModal(null)} />
      )}
      <div
        id="toast-region"
        className="toast-region"
        role="status"
        aria-live="polite"
      >
        {toasts.map((t) => (
          <div key={t.id} className={`toast ${t.kind}`}>
            {t.message}
          </div>
        ))}
      </div>
    </>
  );
}

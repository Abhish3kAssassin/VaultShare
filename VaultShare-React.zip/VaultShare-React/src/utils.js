export const bytes = (n) =>
  n < 1024
    ? `${n} B`
    : n < 1048576
      ? `${(n / 1024).toFixed(1)} KB`
      : `${(n / 1048576).toFixed(1)} MB`;
export const initials = (name) =>
  name
    .split(/\s+/)
    .map((s) => s[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
export const date = (timestamp) =>
  new Date(timestamp * 1000).toLocaleString(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
export function expiry(transfer, offset = 0) {
  const seconds = transfer.expires_at - (Date.now() / 1000 + offset);
  if (seconds <= 0) return "Expiry reached";
  if (seconds < 3600) return `${Math.max(1, Math.ceil(seconds / 60))}m left`;
  if (seconds < 86400) return `${Math.ceil(seconds / 3600)}h left`;
  return `${Math.ceil(seconds / 86400)}d left`;
}

import { useState } from "react";
import Icon, { Brand } from "./Icon";
import { bytes, date, expiry, initials } from "../utils";
const titles = {
  overview: "Overview",
  incoming: "Incoming",
  outgoing: "Sent files",
  activity: "Activity log",
};
const actions = {
  registered: "Created an account",
  signed_in: "Signed in",
  signed_out: "Signed out",
  requested: "Sent a transfer request",
  accepted: "Accepted a transfer",
  declined: "Declined a transfer",
  revoked: "Revoked access",
  expired: "Transfer expired",
  download_verified: "Download verified and served",
  integrity_failed: "Integrity check failed — download blocked",
};
export default function Dashboard({
  user,
  data,
  connected,
  offset,
  onSend,
  onLogout,
  onSecurity,
  onDetail,
  onDecision,
  onDownload,
  busyIds,
  downloadIds,
}) {
  const [page, setPage] = useState("overview"),
    [filter, setFilter] = useState("all"),
    [search, setSearch] = useState("");
  const pending = data.transfers.filter(
    (t) => t.direction === "incoming" && t.status === "pending",
  ).length;
  const ready = data.transfers.filter(
    (t) => t.direction === "incoming" && t.status === "accepted",
  ).length;
  const activeFilter = page === "overview" ? filter : page;
  const transfers = data.transfers.filter(
    (t) =>
      (activeFilter === "all" || t.direction === activeFilter) &&
      `${t.name} ${t.sender.display_name} ${t.recipient.display_name}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  const heading =
    page === "overview"
      ? `Good to see you, ${user.display_name.split(" ")[0]}.`
      : {
          incoming: "Your incoming files.",
          outgoing: "Shared by you.",
          activity: "Every transfer has a story.",
        }[page];
  return (
    <div id="app-screen" className="app-shell">
      <aside className="sidebar">
        <Brand />
        <span className="sidebar-label">WORKSPACE</span>
        <nav aria-label="Main navigation">
          {[
            ["overview", "grid"],
            ["incoming", "inbox"],
            ["outgoing", "send"],
            ["activity", "clock"],
          ].map(([key, name]) => (
            <button
              key={key}
              data-page={key}
              className={`nav-item ${page === key ? "active" : ""}`}
              aria-current={page === key ? "page" : undefined}
              onClick={() => {
                setPage(key);
                setSearch("");
              }}
            >
              <Icon name={name} />
              {titles[key]}
              {key === "incoming" && pending > 0 && (
                <span className="nav-badge">{pending}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="private-card">
            <Icon name="shield" />
            <strong>A little more private.</strong>
            <p>
              Your files stay on this host.
              <br />
              Your sharing stays in your control.
            </p>
            <span className="private-tag">LOCAL NETWORK</span>
          </div>
          <div className="profile">
            <span className="avatar">{initials(user.display_name)}</span>
            <div>
              <strong>{user.display_name}</strong>
              <small>
                <span className="status-dot" />
                Available to share
              </small>
            </div>
            <button
              id="logout"
              className="icon-button"
              aria-label="Sign out"
              onClick={onLogout}
            >
              <Icon name="exit" />
            </button>
          </div>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div className="breadcrumb">
            Workspace<span>/</span>
            <strong>{titles[page]}</strong>
          </div>
          <div className="topbar-right">
            <span className={`connection-pill ${connected ? "" : "offline"}`}>
              <span className="status-dot" />
              {connected ? "LAN connected" : "Reconnecting…"}
            </span>
            <span className="header-divider" />
            <button
              className="icon-button"
              aria-label="Security details"
              onClick={onSecurity}
            >
              <Icon name="shield" />
            </button>
          </div>
        </header>
        <div className="workspace">
          <div className="page-heading">
            <div>
              <span className="eyebrow muted">YOUR PRIVATE SHARING SPACE</span>
              <h1>{heading}</h1>
              <p>
                {
                  {
                    overview:
                      "Big ideas. Small network. Everything in one place.",
                    incoming: "You decide what comes into your vault.",
                    outgoing: "Keep an eye on everything you’ve sent.",
                    activity:
                      "A private record of requests, approvals, and verified downloads.",
                  }[page]
                }
              </p>
            </div>
            <button
              id="new-transfer"
              className="button primary"
              onClick={() => onSend()}
            >
              <Icon name="plus" />
              New transfer
            </button>
          </div>
          <div className="transport-warning">
            HTTP connection · Encrypted storage on the host. Network traffic is
            not encrypted.
          </div>
          {page === "overview" && (
            <section className="hero">
              <div className="hero-copy">
                <span className="hero-kicker">
                  <span className="status-dot" />
                  CLOSE CONNECTIONS. SIMPLE SHARING.
                </span>
                <h2>
                  Send something great.
                  <br />
                  Keep it close.
                </h2>
                <p>
                  Files and folders, shared on your local network.
                  <br />
                  The receiver always gets the final say.
                </p>
                <button className="button hero-button" onClick={() => onSend()}>
                  Share a file
                  <Icon name="arrow" />
                </button>
              </div>
              <div className="hero-art" aria-hidden="true">
                <div className="hero-ring ring-a" />
                <div className="hero-ring ring-b" />
                <div className="hero-folder">
                  <Icon name="folder" />
                  <span>your next big thing</span>
                  <div className="folder-lines" />
                </div>
                <div className="hero-lock">
                  <Icon name="lock" />
                </div>
                <div className="hero-verified">
                  <Icon name="check" />
                  Protected storage
                </div>
                <span className="hero-spark spark-a">+</span>
                <span className="hero-spark spark-b">+</span>
              </div>
            </section>
          )}
          {page !== "activity" && (
            <section className="stats" aria-label="Transfer statistics">
              {[
                [
                  "inbox",
                  "blue",
                  "Waiting for you",
                  pending,
                  "Incoming requests",
                ],
                [
                  "check",
                  "green",
                  "Ready to download",
                  ready,
                  "Accepted transfers",
                ],
                [
                  "users",
                  "purple",
                  "People nearby",
                  data.users.length,
                  "Online on your LAN",
                ],
              ].map(([name, tone, label, value, note]) => (
                <div key={label} className="stat-card">
                  <span className={`stat-icon ${tone}`}>
                    <Icon name={name} />
                  </span>
                  <div>
                    <span>{label}</span>
                    <strong>{value}</strong>
                  </div>
                  <small>{note}</small>
                </div>
              ))}
            </section>
          )}
          <div className="content-grid">
            <section className="transfer-section">
              <div className="section-heading">
                <div>
                  <h2>
                    {
                      {
                        overview: "Your transfers",
                        incoming: "Incoming requests",
                        outgoing: "Sent transfers",
                        activity: "Recent activity",
                      }[page]
                    }
                    <span className="count-label">
                      {page === "activity"
                        ? data.logs.length
                        : transfers.length}
                    </span>
                  </h2>
                  <p>
                    {page === "activity"
                      ? "Visible only to people involved in each transfer."
                      : "A clear view of what’s coming and going."}
                  </p>
                </div>
                {page !== "activity" && (
                  <label className="search-box">
                    <Icon name="search" />
                    <input
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      placeholder="Search files…"
                      aria-label="Search transfers"
                    />
                  </label>
                )}
              </div>
              {page === "overview" && (
                <div className="transfer-tabs">
                  {[
                    ["all", "All transfers"],
                    ["incoming", "Incoming"],
                    ["outgoing", "Sent"],
                  ].map(([key, label]) => (
                    <button
                      key={key}
                      className={filter === key ? "active" : ""}
                      onClick={() => setFilter(key)}
                    >
                      {label}
                      {key === "incoming" && pending > 0 && (
                        <span>{pending}</span>
                      )}
                    </button>
                  ))}
                </div>
              )}
              {page === "activity" ? (
                <div id="activity-list" className="activity-list">
                  {data.logs.map((l) => (
                    <div className="activity-row" key={l.id}>
                      <div
                        className={`stat-icon ${["download_verified", "accepted"].includes(l.action) ? "green" : "blue"}`}
                      >
                        <Icon
                          name={
                            l.action === "download_verified"
                              ? "shield"
                              : l.action === "requested"
                                ? "send"
                                : "clock"
                          }
                        />
                      </div>
                      <div>
                        <strong>{actions[l.action] || l.action}</strong>
                        <p>
                          {l.action === "expired"
                            ? "Automatic expiry"
                            : l.actor_name}
                          {l.detail && ` · ${l.detail}`}
                        </p>
                      </div>
                      <time>{date(l.at)}</time>
                    </div>
                  ))}
                </div>
              ) : (
                <div id="transfer-list" className="transfer-list">
                  {transfers.length ? (
                    transfers.map((t) => (
                      <TransferCard
                        key={t.id}
                        transfer={t}
                        offset={offset}
                        onDetail={() => onDetail(t.id)}
                        onDecision={(action) => onDecision(t.id, action)}
                        onDownload={() => onDownload(t)}
                        busy={busyIds.has(t.id)}
                        downloading={downloadIds.has(t.id)}
                      />
                    ))
                  ) : (
                    <div className="empty-state">
                      <Icon name={search ? "search" : "inbox"} />
                      <h3>
                        {search
                          ? "Nothing matches just yet."
                          : activeFilter === "incoming"
                            ? "Your inbox has room for something good."
                            : "Your next great transfer starts here."}
                      </h3>
                      <p>
                        {search
                          ? "Try another file name or person."
                          : activeFilter === "incoming"
                            ? "Incoming requests appear here. You approve each one before downloading."
                            : "Pick someone nearby, choose a file or folder, and send a request."}
                      </p>
                      {!search && activeFilter !== "incoming" && (
                        <button
                          className="button secondary"
                          onClick={() => onSend()}
                        >
                          <Icon name="plus" />
                          Start a transfer
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </section>
            <aside className="right-rail">
              <section className="people-panel">
                <div className="section-heading">
                  <h2>
                    People nearby
                    <span className="count-label">{data.users.length}</span>
                  </h2>
                  <span className="live-label">
                    <span className="status-dot" />
                    LIVE
                  </span>
                </div>
                <p className="panel-subtitle">Good company. Same network.</p>
                <div id="people-list">
                  {data.users.length ? (
                    data.users.map((u, i) => (
                      <div key={u.id} className="person-row">
                        <span className={`avatar tone-${i % 4}`}>
                          {initials(u.display_name)}
                        </span>
                        <div>
                          <strong>{u.display_name}</strong>
                          <small>
                            <span className="status-dot" />@{u.username}
                          </small>
                        </div>
                        <button
                          className="icon-button"
                          aria-label={`Send to ${u.display_name}`}
                          onClick={() => onSend(u.id)}
                        >
                          <Icon name="send" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="people-empty">
                      <Icon name="users" />
                      {connected ? (
                        <>
                          A little quiet here.
                          <br />
                          Invite someone to open this host’s LAN address.
                        </>
                      ) : (
                        <>
                          Waiting for the host.
                          <br />
                          People reappear when connected.
                        </>
                      )}
                    </div>
                  )}
                </div>
                <div className="people-footer">
                  <Icon name="network" />
                  Updates automatically every 5 seconds
                </div>
              </section>
              <section className="how-panel">
                <div className="how-title">
                  <Icon name="info" />
                  <h3>Sharing, with a say.</h3>
                </div>
                {[
                  "Choose a person and your files.",
                  "They review and accept your request.",
                  "Download after integrity verification.",
                ].map((line, i) => (
                  <div key={line} className="how-step">
                    <span>0{i + 1}</span>
                    <p>{line}</p>
                  </div>
                ))}
                <div className="how-bottom">
                  <Icon name="lock" />
                  Private access. Automatic expiry.
                </div>
              </section>
            </aside>
          </div>
          <footer className="workspace-footer">
            <span>
              <Icon name="shield" />
              Your network. Your rules.
            </span>
            <span>
              Vault Share<span className="footer-dot">•</span>Local-first
              sharing
            </span>
          </footer>
        </div>
      </main>
    </div>
  );
}
function TransferCard({
  transfer: t,
  offset,
  onDetail,
  onDecision,
  onDownload,
  busy,
  downloading,
}) {
  const incoming = t.direction === "incoming",
    live = ["pending", "accepted"].includes(t.status),
    partner = incoming ? t.sender : t.recipient;
  const label = {
    pending: incoming ? "Needs your approval" : "Awaiting approval",
    accepted: "Accepted",
    declined: "Declined",
    expired: "Expired",
    revoked: "Revoked",
    corrupt: "Integrity failed",
  }[t.status];
  return (
    <article className="transfer-card">
      <div className="transfer-card-body">
        <div className={`file-icon ${t.kind === "file" ? "" : "folder"}`}>
          <Icon name={t.kind === "file" ? "file" : "folder"} />
        </div>
        <div className="transfer-info">
          <button
            className="file-title"
            onClick={onDetail}
            title={`View ${t.name} details`}
          >
            {t.name}
          </button>
          <div className="file-meta">
            <span>{bytes(t.size)}</span>
            <span className="meta-dot">·</span>
            <span>
              {t.file_count} {t.file_count === 1 ? "file" : "files"}
            </span>
            <span className="meta-dot">·</span>
            <span>{date(t.created_at)}</span>
          </div>
          <div className="transfer-person">
            <Icon name={incoming ? "inbox" : "send"} />
            {incoming ? "From" : "To"} {partner.display_name}
          </div>
        </div>
        <div className="transfer-side">
          <span className={`badge ${t.status}`}>{label}</span>
          <span className="expiry-label">
            <Icon name="clock" />
            {live ? expiry(t, offset) : `${t.downloads} verified downloads`}
          </span>
        </div>
      </div>
      <div className="transfer-actions">
        <span>
          <Icon name="lock" />
          {t.status === "pending"
            ? "Private until accepted"
            : t.status === "accepted"
              ? "Verified before download"
              : "Payload unavailable"}
        </span>
        <div className="action-buttons">
          {incoming && t.status === "pending" && (
            <>
              <button
                className="button secondary"
                disabled={busy}
                onClick={() => onDecision("decline")}
              >
                Decline
              </button>
              <button
                className="button primary"
                disabled={busy}
                onClick={() => onDecision("accept")}
              >
                <Icon name="check" />
                Accept
              </button>
            </>
          )}
          {incoming && t.status === "accepted" && (
            <button
              className="button primary"
              disabled={downloading}
              onClick={onDownload}
            >
              <Icon name="download" />
              {downloading ? "Verifying…" : "Download"}
            </button>
          )}
          {!incoming && live && (
            <button
              className="button secondary"
              disabled={busy}
              onClick={() => onDecision("revoke")}
            >
              Revoke access
            </button>
          )}
          <button
            className="icon-button"
            aria-label="View transfer details"
            onClick={onDetail}
          >
            <Icon name="info" />
          </button>
        </div>
      </div>
    </article>
  );
}

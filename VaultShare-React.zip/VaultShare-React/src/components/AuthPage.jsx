import { useState } from "react";
import Icon, { Brand } from "./Icon";
export default function AuthPage({ onAuthenticate }) {
  const [mode, setMode] = useState("login"),
    [visible, setVisible] = useState(false),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const register = mode === "register";
  async function submit(event) {
    event.preventDefault();
    setError("");
    setBusy(true);
    const form = new FormData(event.currentTarget);
    try {
      await onAuthenticate(mode, Object.fromEntries(form));
    } catch (error) {
      setError(error.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <section id="auth-screen" className="auth-screen">
      <div className="auth-story">
        <Brand />
        <div className="story-body">
          <span className="eyebrow">BUILT FOR YOUR INNER CIRCLE</span>
          <h1>
            Your network.
            <br />
            Your files.
            <br />
            <span>Your control.</span>
          </h1>
          <p>
            A private space to share with people nearby.
            <br />
            No cloud detours. Just a more thoughtful transfer.
          </p>
          <div className="vault-art">
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="art-card art-file">
              <Icon name="folder" />
              <div>
                <strong>Your project</strong>
                <small>Ready to share</small>
              </div>
            </div>
            <div className="art-lock">
              <Icon name="lock" />
            </div>
            <div className="art-card art-approval">
              <span className="check-dot">
                <Icon name="check" />
              </span>
              <div>
                <strong>You’re in control</strong>
                <small>Approval before access</small>
              </div>
            </div>
            <span className="art-node node-one" />
            <span className="art-node node-two" />
          </div>
        </div>
        <div className="story-footer">
          <Icon name="shield" />
          AES-256-GCM storage<span>•</span>SHA-256 verification
        </div>
      </div>
      <div className="auth-panel">
        <div className="auth-form-wrap">
          <span className="pill">
            <span className="status-dot" /> LOCAL FIRST. PEOPLE FIRST.
          </span>
          <h2>{register ? "Make yourself at home." : "Welcome back."}</h2>
          <p className="muted">
            {register
              ? "Your own space on the local network."
              : "Your files are right where you left them."}
          </p>
          <div className="auth-tabs">
            <button
              type="button"
              className={!register ? "active" : ""}
              onClick={() => {
                setMode("login");
                setError("");
              }}
            >
              Sign in
            </button>
            <button
              type="button"
              className={register ? "active" : ""}
              onClick={() => {
                setMode("register");
                setError("");
              }}
            >
              Create account
            </button>
          </div>
          <form id="auth-form" onSubmit={submit}>
            {register && (
              <label>
                Display name
                <input
                  id="display-name"
                  name="display_name"
                  required
                  maxLength="48"
                  autoComplete="name"
                  placeholder="What should we call you?"
                />
              </label>
            )}
            <label>
              Username
              <input
                id="username"
                name="username"
                autoComplete="username"
                required
                minLength="3"
                maxLength="24"
                pattern="[a-zA-Z0-9_]{3,24}"
                placeholder="Your username"
              />
            </label>
            <label>
              Password
              <div className="password-wrap">
                <input
                  id="password"
                  name="password"
                  type={visible ? "text" : "password"}
                  autoComplete={register ? "new-password" : "current-password"}
                  required
                  minLength={register ? 12 : 1}
                  maxLength="256"
                  placeholder="Enter your password"
                />
                <button
                  type="button"
                  className="text-button"
                  onClick={() => setVisible((v) => !v)}
                >
                  {visible ? "Hide" : "Show"}
                </button>
              </div>
              {register && (
                <small>
                  At least 12 characters. A memorable phrase works well.
                </small>
              )}
            </label>
            {error && (
              <p className="form-error" role="alert">
                {error}
              </p>
            )}
            <button
              className="button primary auth-submit"
              type="submit"
              disabled={busy}
            >
              <span>
                {busy
                  ? "Opening…"
                  : register
                    ? "Create my account"
                    : "Open my vault"}
              </span>
              <Icon name="arrow" />
            </button>
          </form>
          <p className="auth-note">
            <Icon name="network" />
            Everyone connects to the same host on your LAN.
          </p>
          <div className="transport-warning">
            HTTP connection. Stored files are encrypted; network traffic is not
            encrypted.
          </div>
        </div>
        <p className="auth-bottom">Private by design. Shared by choice.</p>
      </div>
    </section>
  );
}

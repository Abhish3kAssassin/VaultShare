import { useEffect, useRef, useState } from "react";
import Icon from "./Icon";
import { bytes, date } from "../utils";
export function Modal({ id, children, onClose, busy = false, className = "" }) {
  const ref = useRef(null);
  useEffect(() => {
    const dialog = ref.current;
    dialog.showModal();
    return () => {
      if (dialog.open) dialog.close();
    };
  }, []);
  return (
    <dialog
      id={id}
      ref={ref}
      className={`modal ${className}`}
      onCancel={(event) => {
        event.preventDefault();
        if (!busy) onClose();
      }}
    >
      {children}
    </dialog>
  );
}
function Close({ onClose, busy = false }) {
  return (
    <button
      type="button"
      className="icon-button"
      disabled={busy}
      onClick={onClose}
      aria-label="Close"
    >
      <Icon name="x" />
    </button>
  );
}
export function SendModal({
  users,
  maxUpload,
  initialRecipient,
  onClose,
  onSend,
}) {
  const [recipient, setRecipient] = useState(initialRecipient || ""),
    [files, setFiles] = useState([]),
    [hours, setHours] = useState("24"),
    [note, setNote] = useState(""),
    [busy, setBusy] = useState(false),
    [progress, setProgress] = useState(0),
    [error, setError] = useState(""),
    [drag, setDrag] = useState(false);
  const fileInput = useRef(),
    folderInput = useRef();
  function choose(selected) {
    setFiles(
      [...selected].map((file) => ({
        file,
        path: file.webkitRelativePath || file.name,
      })),
    );
    setError("");
  }
  async function submit(event) {
    event.preventDefault();
    setError("");
    if (
      !files.length ||
      files.length > 2000 ||
      files.reduce((sum, s) => sum + s.file.size, 0) > maxUpload * 1048576
    ) {
      setError(`Choose 1–2000 files totaling at most ${maxUpload} MB.`);
      return;
    }
    const data = new FormData();
    data.append("recipient_id", recipient);
    data.append("expiry_hours", hours);
    data.append("note", note);
    data.append("paths", JSON.stringify(files.map((s) => s.path)));
    files.forEach((s) => data.append("files", s.file, s.file.name));
    setBusy(true);
    try {
      await onSend(data, setProgress);
      onClose();
    } catch (error) {
      setError(error.message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal id="send-dialog" onClose={onClose} busy={busy}>
      <form id="send-form" onSubmit={submit}>
        <div className="modal-heading">
          <div>
            <span className="eyebrow muted">GOOD THINGS ARE BETTER SHARED</span>
            <h2>New transfer</h2>
          </div>
          <Close onClose={onClose} busy={busy} />
        </div>
        <p className="muted modal-intro">
          Send a little something. They decide when to let it in.
        </p>
        <fieldset className="form-fieldset" disabled={busy}>
          <label>
            Send to
            <select
              id="recipient"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              required
            >
              <option value="">Choose someone online</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.display_name} (@{u.username})
                </option>
              ))}
            </select>
          </label>
          <div
            id="dropzone"
            className={`dropzone ${drag ? "drag-over" : ""}`}
            onDragOver={(event) => {
              event.preventDefault();
              if (!busy) setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(event) => {
              event.preventDefault();
              setDrag(false);
              if (busy) return;
              if (
                [...event.dataTransfer.items].some(
                  (item) => item.webkitGetAsEntry?.()?.isDirectory,
                )
              ) {
                setError("Use Choose folder to preserve directory paths.");
                return;
              }
              choose(event.dataTransfer.files);
            }}
          >
            <div className="drop-icon">
              <Icon name="upload" />
            </div>
            <strong>Drop files here</strong>
            <p>Or choose files or a whole folder below</p>
            <div className="picker-buttons">
              <button
                type="button"
                className="button secondary"
                onClick={() => fileInput.current.click()}
              >
                Choose files
              </button>
              <button
                type="button"
                className="button secondary"
                onClick={() => folderInput.current.click()}
              >
                <Icon name="folder" />
                Choose folder
              </button>
            </div>
            <small>
              Up to {maxUpload} MB · Maximum 2,000 files · Folders download as
              ZIP
            </small>
          </div>
          <input
            id="files-input"
            ref={fileInput}
            type="file"
            multiple
            hidden
            onChange={(event) => choose(event.target.files)}
          />
          <input
            id="folder-input"
            ref={folderInput}
            type="file"
            webkitdirectory=""
            multiple
            hidden
            onChange={(event) => choose(event.target.files)}
          />
          {!!files.length && (
            <div id="selected-files" className="selected-files">
              <div className="selection-header">
                <strong>
                  {files.length} {files.length === 1 ? "file" : "files"} ·{" "}
                  {bytes(files.reduce((sum, s) => sum + s.file.size, 0))}
                </strong>
                <button
                  type="button"
                  className="text-button"
                  onClick={() => {
                    setFiles([]);
                    fileInput.current.value = "";
                    folderInput.current.value = "";
                  }}
                >
                  Clear
                </button>
              </div>
              <ul>
                {files.slice(0, 5).map((s) => (
                  <li key={s.path}>{s.path}</li>
                ))}
                {files.length > 5 && <li>And {files.length - 5} more…</li>}
              </ul>
            </div>
          )}
          <div className="form-row">
            <label>
              Access expires after
              <select
                id="expiry"
                value={hours}
                onChange={(e) => setHours(e.target.value)}
              >
                {[
                  ["1", "1 hour"],
                  ["6", "6 hours"],
                  ["24", "24 hours"],
                  ["72", "3 days"],
                  ["168", "7 days"],
                ].map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span>
                Message <span className="optional">(optional)</span>
              </span>
              <input
                id="transfer-note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                maxLength="280"
                placeholder="A little context…"
              />
            </label>
          </div>
        </fieldset>
        <p className="approval-note">
          <Icon name="shield" />
          Only this receiver can accept and download. Expiry starts when you
          send.
        </p>
        {busy && (
          <div className="upload-progress">
            <progress max="100" value={progress} />
            <span>
              {progress < 100
                ? `Uploading… ${progress}%`
                : "Encrypting and preparing your request…"}
            </span>
          </div>
        )}
        {(error || !users.length) && (
          <p className="form-error" role="alert">
            {error ||
              "No one else is online. Ask someone to open this host’s LAN address and sign in."}
          </p>
        )}
        <div className="modal-footer">
          <button
            type="button"
            className="button secondary"
            disabled={busy}
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            id="send-submit"
            type="submit"
            className="button primary"
            disabled={busy || !users.length}
          >
            <Icon name={busy ? "lock" : "send"} />
            {busy ? "Sending…" : "Send request"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
export function DetailModal({ transfer: t, onClose }) {
  return (
    <Modal id="detail-dialog" className="detail-modal" onClose={onClose}>
      <div className="modal-heading">
        <h2>Transfer details</h2>
        <Close onClose={onClose} />
      </div>
      <h3 className="detail-title">{t.name}</h3>
      <span className={`badge ${t.status}`}>{t.status}</span>
      <dl className="detail-grid">
        {[
          ["From", `${t.sender.display_name} (@${t.sender.username})`],
          ["To", `${t.recipient.display_name} (@${t.recipient.username})`],
          ["Sent", date(t.created_at)],
          ["Expires", date(t.expires_at)],
          ["Payload size", bytes(t.size)],
          ["Verified downloads served", t.downloads],
        ].map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>
      {t.note && <p className="detail-note">{t.note}</p>}
      <p className="hash-label">PAYLOAD SHA-256</p>
      <div className="hash-box">{t.sha256}</div>
      <p className="hash-label">FILES IN THIS TRANSFER</p>
      <ul className="detail-files">
        {t.entries.map((entry) => (
          <li key={entry.path}>
            <span>{entry.path}</span>
            <span>{bytes(entry.size)}</span>
          </li>
        ))}
      </ul>
      <p className="detail-footnote">
        Expiry stops future access. Previously downloaded copies remain with the
        receiver.
      </p>
    </Modal>
  );
}
export function SecurityModal({ onClose }) {
  return (
    <Modal id="security-dialog" onClose={onClose}>
      <div className="modal-heading">
        <h2>Your vault, explained.</h2>
        <Close onClose={onClose} />
      </div>
      <div className="security-explain">
        <Icon name="shield" />
        <h3>Private by design.</h3>
        <p>
          Payloads use AES-256-GCM encryption on this host. Downloads are
          authenticated and checked against SHA-256 before being served.
        </p>
        <p>
          Only the selected receiver can approve and download. Declined,
          revoked, expired, and corrupt payloads are removed from active
          storage.
        </p>
        <p>
          This app connects over HTTP. Passwords and file contents are not
          encrypted during transmission. The host holds the decryption key; this
          is not end-to-end encryption.
        </p>
        <p>
          Expiry and revocation stop future downloads. They cannot remove copies
          already downloaded. Logs record verified downloads served, not proof
          that a browser saved the file.
        </p>
      </div>
    </Modal>
  );
}

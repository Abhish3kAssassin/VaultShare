const paths = {
  send: "m21 3-7 18-4-7-7-4 18-7Z M10 14 21 3",
  inbox: "M4 4h16l2 11v5H2v-5L4 4Z M2 15h6l2 3h4l2-3h6",
  clock: "M12 7v5l3 2",
  users: "M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6m2 4a5 5 0 0 1 3 5",
  shield: "m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6l8-4Z M8 12l3 3 5-6",
  file: "M5 3h9l5 5v13H5V3Z M14 3v5h5M8 13h8m-8 4h5",
  folder: "M3 6h7l2 3h9v11H3V6Z",
  plus: "M12 5v14M5 12h14",
  arrow: "M4 12h16m-6-6 6 6-6 6",
  download: "M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5",
  upload: "M12 16V3m-5 5 5-5 5 5M4 16v5h16v-5",
  check: "m5 12 4 4L19 6",
  x: "m6 6 12 12M6 18 18 6",
  lock: "M8 10V7a4 4 0 0 1 8 0v3m-4 5v2",
  search: "m15 15 6 6",
  exit: "M10 3H4v18h6m4-14 5 5-5 5m-5-5h11",
  network: "M12 8v6M4 14h16M4 14v3m16-3v3",
  info: "M12 11v6m0-10v1",
};
export default function Icon({ name }) {
  return (
    <svg className="icon" viewBox="0 0 24 24" aria-hidden="true">
      {name === "grid" ? (
        <>
          {[
            [3, 3],
            [14, 3],
            [3, 14],
            [14, 14],
          ].map(([x, y]) => (
            <rect key={`${x},${y}`} x={x} y={y} width="7" height="7" rx="2" />
          ))}
        </>
      ) : (
        <>
          {paths[name] && <path d={paths[name]} />}
          {["clock", "info"].includes(name) && <circle cx="12" cy="12" r="9" />}
          {name === "users" && <circle cx="9" cy="8" r="3" />}
          {name === "search" && <circle cx="10" cy="10" r="6" />}
          {name === "lock" && (
            <rect x="5" y="10" width="14" height="11" rx="3" />
          )}
          {name === "network" && (
            <>
              <rect x="8" y="2" width="8" height="6" rx="1" />
              <rect x="1" y="17" width="6" height="5" rx="1" />
              <rect x="17" y="17" width="6" height="5" rx="1" />
            </>
          )}
        </>
      )}
    </svg>
  );
}
export function Brand() {
  return (
    <a className="brand" href="/">
      <span className="brand-mark">V</span>
      <span>
        vault<span className="brand-light">share</span>
        <span className="brand-dot">.</span>
      </span>
    </a>
  );
}

let csrf = "";
export const setCSRF = (value) => {
  csrf = value || "";
};
export async function request(url, { body, ...options } = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      "X-CSRF-Token": csrf,
      ...options.headers,
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json();
  if (!response.ok) {
    const error = new Error(data.error || "Request failed.");
    error.status = response.status;
    throw error;
  }
  return data;
}
export function upload(formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/transfers");
    xhr.setRequestHeader("X-CSRF-Token", csrf);
    xhr.timeout = 300000;
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable)
        onProgress(Math.round((event.loaded / event.total) * 100));
    };
    xhr.onload = () => {
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) resolve(data);
        else reject(new Error(data.error || "Upload failed."));
      } catch {
        reject(new Error("Unexpected server response."));
      }
    };
    xhr.onerror = () =>
      reject(new Error("Could not reach the host. Check the LAN connection."));
    xhr.ontimeout = () =>
      reject(
        new Error("Upload timed out. Check your transfers before retrying."),
      );
    xhr.send(formData);
  });
}
export async function downloadTransfer(transfer) {
  const response = await fetch(`/api/transfers/${transfer.id}/download`, {
    credentials: "same-origin",
  });
  if (!response.ok) {
    const data = await response.json();
    throw new Error(data.error || "Download blocked.");
  }
  const blob = await response.blob(),
    expected = response.headers.get("X-VaultShare-SHA256");
  if (!expected || expected !== transfer.sha256)
    throw new Error("The transfer hash changed. Download blocked.");
  let browserVerified = false;
  if (window.crypto?.subtle) {
    const digest = await crypto.subtle.digest(
      "SHA-256",
      await blob.arrayBuffer(),
    );
    const actual = [...new Uint8Array(digest)]
      .map((n) => n.toString(16).padStart(2, "0"))
      .join("");
    if (actual !== expected)
      throw new Error("Browser SHA-256 verification failed.");
    browserVerified = true;
  }
  const url = URL.createObjectURL(blob),
    link = document.createElement("a");
  link.href = url;
  link.download = transfer.name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  return browserVerified;
}

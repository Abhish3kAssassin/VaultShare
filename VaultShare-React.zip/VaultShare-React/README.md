# Vault Share · React edition

A modern LAN file-sharing app with a React interface and Node.js host. One host serves the interface and API over **HTTP on port 8080**. Other computers only need a browser.

## Start on your MacBook

1. Install **Node.js 22.12 or newer** from https://nodejs.org/ if it is not installed. Node.js 24 LTS is suitable.
2. Extract `VaultShare-React.zip`. Keep the complete project folder together.
3. Stop the old Python Vault Share host with **Ctrl+C** in its terminal, especially if it already uses port 8080.
4. Open Terminal, enter the extracted folder, and run:

```bash
cd /path/to/VaultShare-React
npm ci
npm start
```

`npm ci` downloads the dependencies once. `npm start` builds the React interface and starts the HTTP server on `0.0.0.0:8080`. Later starts need only `npm start`; installed dependencies and assets work without internet. The host opens its browser after a successful local HTTP check. Keep the terminal open.

The terminal prints addresses similar to:

```text
On this computer: http://127.0.0.1:8080
On Windows / other LAN devices: http://192.168.1.42:8080 (en0)
```

On the Mac host, open **http://127.0.0.1:8080**. On Windows, phones, and other computers, open the **LAN address printed by the Mac**. The example `192.168.1.42` must be replaced with your Mac's actual address. `localhost` on Windows points to Windows itself; `0.0.0.0` is a bind setting, not a browser address.

You may also launch with `Start-Mac.command` or `Start-Windows.bat` after installing Node.js. Both install dependencies if needed, then keep the host running. On macOS, if double-clicking is blocked, use the Terminal commands above or run `bash Start-Mac.command` inside this folder.

## Share a file or folder

1. Each person opens the **same host's URL**, creates an account, and signs in.
2. People nearby lists other active users. It refreshes every five seconds; closed or disconnected browsers disappear after about 35 seconds.
3. Choose **New transfer**, select a receiver, and choose files or a folder. Set an expiry window and optional message.
4. The receiver reviews the request and chooses **Accept** or **Decline**. The backend blocks downloading before acceptance.
5. Accepted files can be downloaded by that receiver. Folders and multiple files download as ZIP archives with their relative paths preserved.
6. The sender can revoke access. Expired, declined, revoked, and corrupt payloads are removed; transfer history remains visible to participants.

Expiry starts when the request is sent, including time spent awaiting approval. Empty files are supported; empty directories are not preserved. Previously downloaded copies cannot be recalled.

## If another device still says “refused to connect”

The React rewrite includes correct LAN binding and a single port. A router, VPN, or firewall can still prevent one device from reaching another.

- Wait for **VAULT SHARE REACT IS READY** in the host terminal. If startup fails, follow its error message. Do not close the terminal or let the Mac sleep.
- Use `http://`, the Mac's current Wi-Fi/Ethernet IPv4 address, and the exact printed port. Prefer its physical network address over a VPN or virtual interface.
- Join the same ordinary LAN. Guest Wi-Fi or access-point/client isolation may prevent device-to-device connections.
- On the Mac, allow incoming connections for **Node.js** in System Settings → Network → Firewall → Options. The previous permission for Python does not apply to Node.js. Keep the firewall enabled.
- Disconnect VPNs for a diagnostic attempt. If a school, office, or guest network isolates clients, use a LAN that permits local sharing.

On Windows PowerShell, replace the example IP and test:

```powershell
Test-NetConnection 192.168.1.42 -Port 8080
```

`TcpTestSucceeded: False` means the Windows device cannot establish a TCP connection to that host and port. Check the address, running host, firewall, and network isolation. A browser refresh or changing React code cannot repair that network path.

After installing Node.js, this project also provides a direct HTTP check:

```bash
npm run check -- http://192.168.1.42:8080
```

## Change the port or storage folder

```bash
npm start -- --port 8081
npm start -- --data-dir /absolute/path/to/vault-data
npm start -- --no-browser
npm start -- --max-upload-mb 64 --quota-mb 1024
```

Changing the port requires using that port on every device. Default limits are **128 MiB total input per transfer**, 2,000 files, two concurrent uploads, 2 GiB active payload storage, 512 MiB active payload storage per sender, 100 active transfers per sender, and 500 active transfers per host. Upload processing uses bounded in-memory buffers, so allow enough RAM for uploads, compression, encryption, and downloads. The configurable upload limit is 1–256 MiB.

## Keep existing Python accounts and transfers (optional)

New installs need **no Python**. To import data from the previous Python version, run the included one-time migration **before starting this React app for the first time**:

1. Stop the Python host and back up its complete `data` folder.
2. In the new React project folder run:

```bash
python3 scripts/migrate-python.py --source /absolute/path/to/old/VaultShare/data
npm ci
npm start
```

The migration creates this project's `data` folder, retaining accounts, compatible scrypt password hashes, signed metadata, encryption keys, logs, and active encrypted payloads. Imported accepted transfers stay accepted; pending transfers still require approval. Expired transfers lose access normally. The old data is left untouched. Everyone signs in again; browser sessions are not migrated.

The target must **not already exist**. If you have already started React, use a different new folder and point the host to it:

```bash
python3 scripts/migrate-python.py --source /path/to/old/data --target /path/to/new/imported-data
npm start -- --data-dir /path/to/new/imported-data
```

Do not copy the old `data` folder directly into React or delete `keys.bin`. The importer verifies the old metadata signature and preserves the original authenticated encryption metadata. Migration requires Python 3 only for that one command and uses the standard library.

## Project map

| Path                        | Purpose                                                                   |
| --------------------------- | ------------------------------------------------------------------------- |
| `src/App.jsx`               | React state, sessions, polling, and actions                               |
| `src/components/`           | Login, dashboard, transfer cards, and dialogs                             |
| `src/style.css`             | Responsive appearance                                                     |
| `server/app.mjs`            | Authentication, upload, approval, access control, and download API        |
| `server/store.mjs`          | Signed JSON storage, AES-256-GCM, SHA-256, and expiry                     |
| `server/index.mjs`          | HTTP host, port selection, locking, and LAN URLs                          |
| `scripts/start.mjs`         | Build and serve the entire application                                    |
| `scripts/check.mjs`         | Test a host's HTTP health endpoint                                        |
| `scripts/migrate-python.py` | Optional one-time import from the Python edition                          |
| `data/`                     | Created on first launch; private runtime data, excluded from the download |
| `previews/`                 | Screenshots captured from the running React app                           |

## Development and checks

```bash
npm run dev
```

Development runs the Node API on HTTP port 8080 and Vite on HTTP port 3001 with a local API proxy. Use the port 3001 URL for hot reload. For sharing with normal users, use `npm start` and port 8080.

```bash
npm run build
npm test
npx playwright install chromium
npm run test:browser
```

API/launcher tests exercise authorization, approvals, crypto tampering, expiry, persistence, privacy, upload limits, migration, LAN binding, and startup failures. Browser checks use two isolated sessions and cover folder approval/download, presence, bidirectional sharing, escaped text, revocation, logs, logout, and desktop/mobile layouts. Python is optional for the migration test; it is skipped when unavailable. Browser tests create only temporary accounts and data. Set `VS_BROWSER_PATH` to an installed Chromium executable if needed.

## Data and security

No database is used. The host stores authenticated JSON metadata in `data/state.json`, a 64-byte key file in `data/keys.bin`, and AES-256-GCM payloads in `data/blobs/`. Sessions and presence live in memory. A single host process owns a data folder; do not run two hosts against the same folder. Stop the host before backing up the **entire** folder.

**HTTP is intentional.** Stored file contents are encrypted; network traffic, including passwords and transfers, is not encrypted. The host has the decryption key, so this is not end-to-end encryption. File names, notes, account records, and logs are signed for integrity but are not encrypted. Trust the host and LAN. AES-GCM authentication and SHA-256 are checked before the server sends a download; the browser also checks SHA-256 when Web Crypto is available. On some HTTP LAN origins browsers disable Web Crypto, so the UI reports server verification instead.

See `SECURITY.md` for the implementation's scope and limits. There is no password recovery flow. Keep passwords and the complete data backup safe.

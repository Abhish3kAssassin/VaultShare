import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
const apiProxy = {
  target: "http://127.0.0.1:8080",
  changeOrigin: true,
  configure(proxy) {
    proxy.on("proxyReq", (request) =>
      request.setHeader("Origin", "http://127.0.0.1:8080"),
    );
  },
};
export default defineConfig({
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 3001,
    strictPort: true,
    proxy: { "/api": apiProxy, "/healthz": apiProxy },
  },
});
